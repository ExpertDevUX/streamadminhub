#!/bin/bash
set -e

# Install AWS CLI if not installed
if ! command -v aws &> /dev/null; then
    echo "Installing AWS CLI..."
    apt-get update
    apt-get install -y unzip curl
    curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
    unzip -q awscliv2.zip
    ./aws/install
    rm -rf aws awscliv2.zip
fi

# Create deployment directory
mkdir -p ~/stream-manager
cd ~/stream-manager

# Download deployment files from S3
echo "Downloading deployment files from S3..."
aws s3 cp s3://stream-manager-deployment-1743048279/stream-manager-deploy.tar.gz . --region ap-southeast-1
aws s3 cp s3://stream-manager-deployment-1743048279/aws-install.sh . --region ap-southeast-1

# Extract and run installation
echo "Extracting and installing..."
tar -xzf stream-manager-deploy.tar.gz
chmod +x aws-install.sh
sudo ./aws-install.sh

# Cleanup
echo "Cleaning up temporary files..."
cd ~
rm -rf ~/stream-manager

echo "Deployment completed successfully!"
