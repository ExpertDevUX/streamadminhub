#!/bin/bash
# Script to generate presigned URLs for the Stream Manager deployment files
# Presigned URLs provide temporary access to S3 objects without requiring AWS credentials

# Configuration
BUCKET_NAME="stream-manager-deployment-1743048279"
REGION="ap-southeast-1"
EXPIRATION_TIME="3600"  # URL expiration time in seconds (1 hour)

# Display script header
echo "====================================================="
echo "     Stream Manager Deployment - Presigned URLs      "
echo "====================================================="
echo "Generating presigned URLs that will expire in $(($EXPIRATION_TIME/60)) minutes..."
echo ""

# Generate presigned URLs for each deployment file
# Get all files from the bucket 
files=($(aws s3 ls s3://$BUCKET_NAME/ --recursive | awk '{print $4}' | sort))

for file in "${files[@]}"; do
  presigned_url=$(aws s3 presign --region $REGION --expires-in $EXPIRATION_TIME s3://$BUCKET_NAME/$file)
  echo "File: $file"
  echo "URL: $presigned_url"
  echo "---------------------------------------------------"
done

echo ""
echo "These URLs will expire on: $(date -d "+$EXPIRATION_TIME seconds")"
echo "Share these URLs only with authorized users."
echo "====================================================="