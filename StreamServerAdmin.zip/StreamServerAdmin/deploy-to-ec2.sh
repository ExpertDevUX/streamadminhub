#!/bin/bash

# Stream Manager Deployment Script for AWS EC2
# This script prepares and deploys the Stream Manager to an AWS EC2 instance

# Color codes for better readability
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored messages
print_message() {
    echo -e "${2}${1}${NC}"
}

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Check for AWS CLI
if ! command_exists aws; then
    print_message "AWS CLI is not installed. Please install it first." "$RED"
    exit 1
fi

# Make sure we have jq for JSON parsing
if ! command_exists jq; then
    print_message "Installing jq for JSON parsing..." "$YELLOW"
    apt-get update && apt-get install -y jq || {
        print_message "Failed to install jq. Please install it manually." "$RED"
        exit 1
    }
fi

# Default values
INSTANCE_ID=""
KEY_FILE=""
REGION="ap-southeast-1"
USERNAME="ubuntu"

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --instance-id)
            INSTANCE_ID="$2"
            shift 2
            ;;
        --key-file)
            KEY_FILE="$2"
            shift 2
            ;;
        --region)
            REGION="$2"
            shift 2
            ;;
        --username)
            USERNAME="$2"
            shift 2
            ;;
        *)
            print_message "Unknown parameter: $1" "$RED"
            exit 1
            ;;
    esac
done

# Validate required parameters
if [ -z "$INSTANCE_ID" ]; then
    print_message "Instance ID is required. Use --instance-id to specify." "$RED"
    exit 1
fi

if [ -z "$KEY_FILE" ]; then
    print_message "SSH key file is required. Use --key-file to specify." "$RED"
    exit 1
fi

# Get instance information
print_message "Getting information for instance $INSTANCE_ID..." "$BLUE"
INSTANCE_INFO=$(aws ec2 describe-instances --region "$REGION" --instance-ids "$INSTANCE_ID" --query "Reservations[0].Instances[0]")

if [ -z "$INSTANCE_INFO" ]; then
    print_message "Failed to retrieve instance information." "$RED"
    exit 1
fi

PUBLIC_IP=$(echo "$INSTANCE_INFO" | jq -r '.PublicIpAddress')
AVAILABILITY_ZONE=$(echo "$INSTANCE_INFO" | jq -r '.Placement.AvailabilityZone')

if [ -z "$PUBLIC_IP" ] || [ "$PUBLIC_IP" == "null" ]; then
    print_message "Instance does not have a public IP address." "$RED"
    exit 1
fi

print_message "Instance Public IP: $PUBLIC_IP" "$GREEN"
print_message "Availability Zone: $AVAILABILITY_ZONE" "$GREEN"

# Check if we can connect to the instance
print_message "Testing SSH connection to the instance..." "$BLUE"
if ! ssh -i "$KEY_FILE" -o StrictHostKeyChecking=no -o ConnectTimeout=10 "$USERNAME@$PUBLIC_IP" echo "SSH connection successful"; then
    print_message "Failed to connect to the instance via SSH. Please check your key file and security group rules." "$RED"
    exit 1
fi

# S3 bucket containing deployment files
S3_BUCKET="stream-manager-deployment-1743048279"

# Create deployment directory
print_message "Creating deployment directory on the instance..." "$BLUE"
ssh -i "$KEY_FILE" "$USERNAME@$PUBLIC_IP" "mkdir -p ~/stream-manager"

# Download deployment package from S3
print_message "Downloading deployment package from S3..." "$BLUE"
ssh -i "$KEY_FILE" "$USERNAME@$PUBLIC_IP" "aws s3 cp s3://$S3_BUCKET/stream-manager-deploy.tar.gz ~/stream-manager/"

# Extract and setup
print_message "Extracting deployment package and setting up..." "$BLUE"
ssh -i "$KEY_FILE" "$USERNAME@$PUBLIC_IP" "cd ~/stream-manager && tar -xzf stream-manager-deploy.tar.gz && chmod +x install.sh && sudo ./install.sh -y"

print_message "Deployment completed successfully!" "$GREEN"
print_message "Stream Manager is now available at: http://$PUBLIC_IP" "$GREEN"
print_message "Default admin credentials:" "$GREEN"
print_message "Username: admin" "$GREEN"
print_message "Password: Check /etc/stream-manager/credentials.conf on your server" "$GREEN"

print_message "To access your Stream Manager:" "$BLUE"
print_message "1. Open http://$PUBLIC_IP in your browser" "$BLUE"
print_message "2. Log in with the admin credentials" "$BLUE"
print_message "3. Configure your server settings" "$BLUE"

exit 0