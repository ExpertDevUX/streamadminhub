#!/bin/bash

# Direct EC2 Deployment Script for Stream Manager
# This script deploys Stream Manager directly to an EC2 instance using AWS CLI

# Color codes for better readability
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored messages
print_message() {
    echo -e "${2}${1}${NC}"
}

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Check for AWS CLI
if ! command_exists aws; then
    print_message "AWS CLI is not installed. Please install it first." "$RED"
    exit 1
fi

# Check for AWS CLI version (supporting both v1 and v2)
AWS_VERSION=$(aws --version)
print_message "Using AWS CLI: $AWS_VERSION" "$BLUE"

# Default values
INSTANCE_ID=""
REGION="ap-southeast-1"
S3_BUCKET="stream-manager-deployment-1743048279"

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --instance-id)
            INSTANCE_ID="$2"
            shift 2
            ;;
        --region)
            REGION="$2"
            shift 2
            ;;
        --bucket)
            S3_BUCKET="$2"
            shift 2
            ;;
        *)
            print_message "Unknown parameter: $1" "$RED"
            exit 1
            ;;
    esac
done

# Validate required parameters
if [ -z "$INSTANCE_ID" ]; then
    print_message "Instance ID is required. Use --instance-id to specify." "$RED"
    exit 1
fi

# Get instance information
print_message "Getting information for instance $INSTANCE_ID..." "$BLUE"
INSTANCE_INFO=$(aws ec2 describe-instances --region "$REGION" --instance-ids "$INSTANCE_ID" --query "Reservations[0].Instances[0]")

if [ -z "$INSTANCE_INFO" ]; then
    print_message "Failed to retrieve instance information." "$RED"
    exit 1
fi

PUBLIC_IP=$(echo "$INSTANCE_INFO" | jq -r '.PublicIpAddress')
AVAILABILITY_ZONE=$(echo "$INSTANCE_INFO" | jq -r '.Placement.AvailabilityZone')

if [ -z "$PUBLIC_IP" ] || [ "$PUBLIC_IP" == "null" ]; then
    print_message "Instance does not have a public IP address." "$RED"
    exit 1
fi

print_message "Instance Public IP: $PUBLIC_IP" "$GREEN"
print_message "Availability Zone: $AVAILABILITY_ZONE" "$GREEN"

# Run commands on the EC2 instance using EC2 Instance Connect
print_message "Deploying Stream Manager to the instance..." "$BLUE"

# Create deployment script on the instance
DEPLOYMENT_SCRIPT=$(cat <<EOF
#!/bin/bash
set -e

# Install AWS CLI if not installed
if ! command -v aws &> /dev/null; then
    echo "Installing AWS CLI..."
    apt-get update
    apt-get install -y unzip curl
    curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
    unzip -q awscliv2.zip
    ./aws/install
    rm -rf aws awscliv2.zip
fi

# Create deployment directory
mkdir -p ~/stream-manager
cd ~/stream-manager

# Download deployment files from S3
echo "Downloading deployment files from S3..."
aws s3 cp s3://$S3_BUCKET/stream-manager-deploy.tar.gz . --region $REGION
aws s3 cp s3://$S3_BUCKET/aws-install.sh . --region $REGION

# Extract and run installation
echo "Extracting and installing..."
tar -xzf stream-manager-deploy.tar.gz
chmod +x aws-install.sh
sudo ./aws-install.sh

# Cleanup
echo "Cleaning up temporary files..."
cd ~
rm -rf ~/stream-manager

echo "Deployment completed successfully!"
EOF
)

# Generate a unique script name
SCRIPT_NAME="stream-manager-deploy-$(date +%s).sh"

# Save the deployment script locally
echo "$DEPLOYMENT_SCRIPT" > $SCRIPT_NAME
chmod +x $SCRIPT_NAME

# Use EC2 Instance Connect to send the script to the instance and execute it
print_message "Connecting to the instance and running deployment script..." "$BLUE"
aws ec2-instance-connect send-serial-console-ssh-public-key \
    --instance-id $INSTANCE_ID \
    --region $REGION \
    --serial-port 0 \
    --ssh-public-key file://<(ssh-keygen -t rsa -b 2048 -f /tmp/temp_key -N "" >/dev/null 2>&1 && cat /tmp/temp_key.pub)

# Use AWS Systems Manager Run Command to execute the deployment script
COMMAND_ID=$(aws ssm send-command \
    --instance-ids $INSTANCE_ID \
    --region $REGION \
    --document-name "AWS-RunShellScript" \
    --parameters "commands=[$DEPLOYMENT_SCRIPT]" \
    --output text \
    --query "Command.CommandId")

if [ -z "$COMMAND_ID" ]; then
    print_message "Failed to send command to the instance." "$RED"
    print_message "Please ensure the instance has the SSM Agent installed and the proper IAM role." "$RED"
    print_message "Alternatively, you can SSH to the instance and run the following commands manually:" "$YELLOW"
    cat $SCRIPT_NAME
    exit 1
fi

print_message "Deployment command sent to the instance (Command ID: $COMMAND_ID)." "$GREEN"
print_message "Waiting for deployment to complete..." "$BLUE"

# Wait for the command to complete
aws ssm wait command-executed --command-id $COMMAND_ID --instance-id $INSTANCE_ID --region $REGION

print_message "Deployment completed successfully!" "$GREEN"
print_message "Stream Manager is now available at: http://$PUBLIC_IP" "$GREEN"
print_message "Default admin credentials:" "$GREEN"
print_message "Username: admin" "$GREEN"
print_message "Password: Check /etc/stream-manager/credentials.conf on your server" "$GREEN"

print_message "To access your Stream Manager:" "$BLUE"
print_message "1. Open http://$PUBLIC_IP in your browser" "$BLUE"
print_message "2. Log in with the admin credentials" "$BLUE"
print_message "3. Configure your server settings" "$BLUE"

# Clean up
rm -f $SCRIPT_NAME
rm -f /tmp/temp_key /tmp/temp_key.pub

exit 0