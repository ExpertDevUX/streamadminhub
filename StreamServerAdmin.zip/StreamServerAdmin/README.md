# Video Stream Server Manager

A powerful video stream server management platform that simplifies complex server operations through intuitive design and intelligent automation.

## Features

- **User Management**: Secure authentication, role-based access control
- **RTMP Server Management**: Automatic installation script with options for different server resource levels
- **Stream Management**: Create, manage and monitor video streams
- **Embedding**: Embed streams on external websites using iframes and widgets
- **WordPress Integration**: Synchronize with WpStream WordPress plugin
- **Real-time Metrics**: Interactive server health dashboard with WebSockets
- **Storage Management**: Backup creation, restore, and storage optimization
- **VPS Information**: Server performance monitoring and analysis

## Tech Stack

- **Frontend**: React, TypeScript, TailwindCSS, shadcn/ui
- **Backend**: Express.js, Node.js
- **Database**: PostgreSQL with Drizzle ORM
- **Real-time**: WebSockets for live monitoring
- **RTMP**: Node-Media-Server for RTMP handling

## Deployment Options

### 1. Deploy on Replit

The easiest way to deploy this application is directly on Replit:

1. Click the "Deploy" button in the Replit interface
2. Once deployed, your app will be available at a `.replit.app` domain
3. Set up environment variables for database connections if needed

### 2. Deploy to AWS

#### Prerequisites

- An AWS account
- EC2 instance running Ubuntu 20.04 or later
- Basic understanding of AWS services
- Domain name (optional, but recommended for production)

#### S3 Deployment Package

All deployment files are available in our S3 bucket:

```
Bucket Name: stream-manager-deployment-1743048279
Region: ap-southeast-1
```

**Access Requirements**: You need AWS credentials with S3 read access to download files from this bucket. The bucket is not publicly accessible.

**Using Presigned URLs**: Administrators can generate temporary access links using the `generate-presigned-urls.sh` script available in this repository. These links allow temporary access without AWS credentials.

Key files in the bucket:
- `stream-manager-deploy.tar.gz`: Main deployment package
- `aws-install.sh`: AWS-specific installation script
- `deploy-to-ec2.sh`: SSH-based deployment script
- `deploy-direct-ec2.sh`: Direct EC2 Instance Connect deployment script
- `AWS_DEPLOYMENT.md`: Comprehensive deployment guide

#### Deployment Methods

**Option 1: Direct Deployment (EC2 Instance Connect)**

The easiest way to deploy is with our EC2 Instance Connect script:

```bash
# Install AWS CLI if needed
pip install awscli

# Configure AWS credentials if needed
aws configure

# Download the deployment script
aws s3 cp s3://stream-manager-deployment-1743048279/deploy-direct-ec2.sh .
chmod +x deploy-direct-ec2.sh

# Run the deployment script
./deploy-direct-ec2.sh --instance-id i-01c8351c620388fc0 --region ap-southeast-1
```

**Option 2: SSH-based Deployment**

Deploy via SSH from your local machine:

```bash
# Download the deployment script
aws s3 cp s3://stream-manager-deployment-1743048279/deploy-to-ec2.sh .
chmod +x deploy-to-ec2.sh

# Run the deployment script
./deploy-to-ec2.sh --instance-id i-01c8351c620388fc0 --key-file /path/to/your-key.pem --region ap-southeast-1 --username ubuntu
```

**Option 3: Manual Deployment**

For detailed manual deployment instructions, please refer to `AWS_DEPLOYMENT.md` in the S3 bucket:

```bash
aws s3 cp s3://stream-manager-deployment-1743048279/AWS_DEPLOYMENT.md .
```

#### Post-Deployment Configuration

After deploying:

1. **Access the application** at `http://YOUR_EC2_PUBLIC_IP`
2. **Log in with default admin credentials**:
   - Username: `admin`
   - Password: Check `/etc/stream-manager/credentials.conf` on your server
3. **Change the default admin password** immediately
4. **Configure HTTPS** using the built-in SSL Configuration page
5. **Configure your RTMP server** settings as needed

For detailed troubleshooting and configuration options, see `AWS_DEPLOYMENT.md`.

## Development

### Prerequisites

- Node.js 18+ and npm
- PostgreSQL database

### Setup

1. Clone the repository
   ```bash
   git clone https://github.com/yourusername/video-stream-server.git
   cd video-stream-server
   ```

2. Install dependencies
   ```bash
   npm install
   ```

3. Set up environment variables
   ```bash
   # Create a .env file
   DATABASE_URL=postgresql://username:password@localhost:5432/your-database
   PORT=5000
   ```

4. Run the development server
   ```bash
   npm run dev
   ```

### Default Admin Credentials

- Username: `admin`
- Password: `admin123`

**Important**: Change these credentials immediately after first login.

## License

This project is proprietary software.

## Support

For support or inquiries, please contact: info@hwosecurity.org