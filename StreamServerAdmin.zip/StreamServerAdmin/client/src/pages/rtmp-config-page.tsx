import { DashboardLayout } from "@/components/dashboard/layout";
import { useAuth } from "@/hooks/use-auth";
import { Redirect } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Server } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { 
  AlertCircle, 
  CheckCircle, 
  Server as ServerIcon, 
  Download, 
  RefreshCw, 
  Play, 
  StopCircle, 
  Settings, 
  Loader2 
} from "lucide-react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useState } from "react";
import { insertServerSchema } from "@shared/schema";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";

// Form schema for server configuration
const serverConfigSchema = insertServerSchema.extend({
  name: z.string().min(3, "Name must be at least 3 characters"),
  host: z.string().min(1, "Host is required"),
  port: z.coerce.number().int().min(1, "Port must be a positive integer"),
});

type ServerConfigFormValues = z.infer<typeof serverConfigSchema>;

export default function RTMPConfigPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedTabId, setSelectedTabId] = useState<string | null>(null);
  
  // Redirect if not admin
  if (user && !user.isAdmin) {
    return <Redirect to="/" />;
  }

  const { data: servers, isLoading, refetch } = useQuery<Server[]>({
    queryKey: ["/api/servers"],
  });

  const installServerMutation = useMutation({
    mutationFn: async (serverId: number) => {
      const res = await apiRequest("POST", "/api/admin/rtmp/install", { serverId });
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Installation started",
        description: "RTMP server installation has started. This may take a few minutes.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/servers"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Installation failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const startServerMutation = useMutation({
    mutationFn: async (serverId: number) => {
      const res = await apiRequest("POST", "/api/admin/rtmp/start", { serverId });
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Server started",
        description: "RTMP server has been started successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/servers"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to start server",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const stopServerMutation = useMutation({
    mutationFn: async (serverId: number) => {
      const res = await apiRequest("POST", "/api/admin/rtmp/stop", { serverId });
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Server stopped",
        description: "RTMP server has been stopped",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/servers"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to stop server",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const updateServerMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number, data: Partial<Server> }) => {
      const res = await apiRequest("PUT", `/api/admin/servers/${id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Server updated",
        description: "RTMP server configuration has been updated",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/servers"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update server",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const form = useForm<ServerConfigFormValues>({
    resolver: zodResolver(serverConfigSchema),
    defaultValues: {
      name: "",
      host: "localhost",
      port: 1935,
      config: {
        rtmp: { port: 1935, chunk_size: 60000, gop_cache: true, ping: 30, ping_timeout: 60 },
        http: { port: 8000, allow_origin: "*" }
      }
    }
  });

  const handleInstallServer = (serverId: number) => {
    installServerMutation.mutate(serverId);
  };

  const handleStartServer = (serverId: number) => {
    startServerMutation.mutate(serverId);
  };

  const handleStopServer = (serverId: number) => {
    stopServerMutation.mutate(serverId);
  };

  const onSubmit = (data: ServerConfigFormValues) => {
    if (selectedTabId) {
      updateServerMutation.mutate({ 
        id: parseInt(selectedTabId), 
        data 
      });
    }
  };

  // When tab changes, update the form with the selected server's data
  const handleTabChange = (tabId: string) => {
    setSelectedTabId(tabId);
    
    if (servers) {
      const server = servers.find(s => s.id.toString() === tabId);
      if (server) {
        form.reset({
          name: server.name,
          host: server.host,
          port: server.port,
          isInstalled: server.isInstalled,
          status: server.status,
          config: server.config || {
            rtmp: { port: 1935, chunk_size: 60000, gop_cache: true, ping: 30, ping_timeout: 60 },
            http: { port: 8000, allow_origin: "*" }
          }
        });
      }
    }
  };

  return (
    <DashboardLayout title="RTMP Configuration">
      <div className="mb-6 flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">RTMP Server Configuration</h1>
          <p className="text-muted-foreground">
            Configure and manage your RTMP streaming servers
          </p>
        </div>
        
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => refetch()} disabled={isLoading}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>
      
      {isLoading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : servers && servers.length > 0 ? (
        <Tabs defaultValue={servers[0].id.toString()} onValueChange={handleTabChange}>
          <div className="flex justify-between items-center mb-4">
            <TabsList>
              {servers.map(server => (
                <TabsTrigger key={server.id} value={server.id.toString()}>
                  {server.name}
                </TabsTrigger>
              ))}
            </TabsList>
          </div>
          
          {servers.map(server => (
            <TabsContent key={server.id} value={server.id.toString()}>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-2">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between">
                        <span>Server Configuration</span>
                        <Badge variant={server.isInstalled ? "success" : "destructive"}>
                          {server.isInstalled ? "Installed" : "Not Installed"}
                        </Badge>
                      </CardTitle>
                      <CardDescription>
                        Configure your RTMP server settings
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Form {...form}>
                        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                          <FormField
                            control={form.control}
                            name="name"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Server Name</FormLabel>
                                <FormControl>
                                  <Input placeholder="Main RTMP Server" {...field} />
                                </FormControl>
                                <FormDescription>
                                  A descriptive name for this RTMP server
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField
                              control={form.control}
                              name="host"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Host</FormLabel>
                                  <FormControl>
                                    <Input placeholder="localhost" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={form.control}
                              name="port"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>RTMP Port</FormLabel>
                                  <FormControl>
                                    <Input type="number" placeholder="1935" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          
                          <FormField
                            control={form.control}
                            name="config"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Advanced Configuration</FormLabel>
                                <FormControl>
                                  <Textarea 
                                    placeholder="Server configuration"
                                    className="font-mono h-48"
                                    value={JSON.stringify(field.value, null, 2)}
                                    onChange={(e) => {
                                      try {
                                        const parsed = JSON.parse(e.target.value);
                                        field.onChange(parsed);
                                      } catch (e) {
                                        // Don't update if JSON is invalid
                                      }
                                    }}
                                  />
                                </FormControl>
                                <FormDescription>
                                  Advanced RTMP server configuration in JSON format
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <div className="flex justify-end">
                            <Button 
                              type="submit" 
                              disabled={updateServerMutation.isPending || !form.formState.isDirty}
                            >
                              {updateServerMutation.isPending ? (
                                <>
                                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                  Saving...
                                </>
                              ) : (
                                <>
                                  <Settings className="mr-2 h-4 w-4" />
                                  Save Configuration
                                </>
                              )}
                            </Button>
                          </div>
                        </form>
                      </Form>
                    </CardContent>
                  </Card>
                </div>
                
                <div>
                  <Card>
                    <CardHeader>
                      <CardTitle>Server Actions</CardTitle>
                      <CardDescription>
                        Manage your RTMP server instance
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="flex items-center justify-between">
                        <div className="space-y-1">
                          <h4 className="text-sm font-medium">Server Status</h4>
                          <div className="flex items-center">
                            <div className={`h-2.5 w-2.5 rounded-full mr-2 ${
                              server.status === 'online' ? 'bg-green-500' : 'bg-gray-400'
                            }`}></div>
                            <span className="text-sm">
                              {server.status === 'online' ? 'Online' : 'Offline'}
                            </span>
                          </div>
                        </div>
                        
                        <Badge variant={server.status === 'online' ? 'success' : 'secondary'}>
                          {server.status === 'online' ? 'Running' : 'Stopped'}
                        </Badge>
                      </div>
                      
                      {!server.isInstalled && (
                        <Alert variant="destructive">
                          <AlertCircle className="h-4 w-4" />
                          <AlertTitle>Not Installed</AlertTitle>
                          <AlertDescription>
                            RTMP server is not installed. Click Install button to set up.
                          </AlertDescription>
                        </Alert>
                      )}
                      
                      <div className="grid grid-cols-1 gap-3">
                        {!server.isInstalled ? (
                          <Button
                            variant="default"
                            className="w-full"
                            onClick={() => handleInstallServer(server.id)}
                            disabled={installServerMutation.isPending}
                          >
                            {installServerMutation.isPending ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Installing...
                              </>
                            ) : (
                              <>
                                <Download className="mr-2 h-4 w-4" />
                                Install RTMP Server
                              </>
                            )}
                          </Button>
                        ) : server.status !== 'online' ? (
                          <Button
                            variant="default"
                            className="w-full"
                            onClick={() => handleStartServer(server.id)}
                            disabled={startServerMutation.isPending}
                          >
                            {startServerMutation.isPending ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Starting...
                              </>
                            ) : (
                              <>
                                <Play className="mr-2 h-4 w-4" />
                                Start Server
                              </>
                            )}
                          </Button>
                        ) : (
                          <Button
                            variant="outline"
                            className="w-full"
                            onClick={() => handleStopServer(server.id)}
                            disabled={stopServerMutation.isPending}
                          >
                            {stopServerMutation.isPending ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Stopping...
                              </>
                            ) : (
                              <>
                                <StopCircle className="mr-2 h-4 w-4 text-destructive" />
                                Stop Server
                              </>
                            )}
                          </Button>
                        )}
                        
                        <Button
                          variant="outline"
                          className="w-full"
                          onClick={() => {
                            form.reset();
                            // Re-render form with current server data
                            handleTabChange(server.id.toString());
                          }}
                        >
                          Reset Changes
                        </Button>
                      </div>
                    </CardContent>
                    
                    {server.isInstalled && (
                      <CardFooter className="border-t bg-gray-50 px-6 py-3">
                        <div className="space-y-1 w-full">
                          <h4 className="text-sm font-medium">Connection URL</h4>
                          <code className="text-xs bg-gray-100 p-2 block rounded w-full overflow-x-auto">
                            rtmp://{server.host}:{server.port}/live/[stream-key]
                          </code>
                        </div>
                      </CardFooter>
                    )}
                  </Card>
                </div>
              </div>
            </TabsContent>
          ))}
        </Tabs>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>No RTMP Servers Configured</CardTitle>
            <CardDescription>
              You don't have any RTMP servers configured yet.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center justify-center py-8">
            <ServerIcon className="h-16 w-16 text-gray-300 mb-4" />
            <p className="text-center text-gray-500 max-w-md mb-6">
              RTMP servers allow you to receive and manage live video streams. 
              Configure a server to get started with streaming.
            </p>
            <Button onClick={() => {
              // Create a default server
              toast({
                title: "Creating server",
                description: "Setting up default RTMP server configuration",
              });
            }}>
              Configure Default Server
            </Button>
          </CardContent>
        </Card>
      )}
    </DashboardLayout>
  );
}
