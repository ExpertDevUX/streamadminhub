import { DashboardLayout } from "@/components/dashboard/layout";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Stream } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertStreamSchema } from "@shared/schema";
import { z } from "zod";
import { Edit, Trash2, Play, StopCircle, Plus, RefreshCw, Key, Share2 } from "lucide-react";
import { format } from "date-fns";
import { IframeWidget } from "@/components/stream/iframe-widget";

// Extended schema for the form
const createStreamSchema = insertStreamSchema.extend({
  name: z.string().min(3, "Name must be at least 3 characters"),
});

type CreateStreamFormValues = z.infer<typeof createStreamSchema>;

export default function StreamsPage() {
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [generatedKey, setGeneratedKey] = useState("");
  
  const { data: streams, isLoading, refetch } = useQuery<Stream[]>({
    queryKey: ["/api/streams"],
  });
  
  const form = useForm<CreateStreamFormValues>({
    resolver: zodResolver(createStreamSchema),
    defaultValues: {
      name: "",
      streamKey: "",
      isActive: false,
    },
  });
  
  const generateKeyMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/streams/generate-key");
      return await res.json();
    },
    onSuccess: (data) => {
      form.setValue("streamKey", data.streamKey);
      setGeneratedKey(data.streamKey);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to generate stream key",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const createStreamMutation = useMutation({
    mutationFn: async (data: CreateStreamFormValues) => {
      const res = await apiRequest("POST", "/api/streams", data);
      return await res.json();
    },
    onSuccess: () => {
      setDialogOpen(false);
      form.reset();
      toast({
        title: "Stream created",
        description: "Your stream has been created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/streams"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create stream",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const toggleStreamMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: number, isActive: boolean }) => {
      const res = await apiRequest("PUT", `/api/streams/${id}`, { isActive });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/streams"] });
      queryClient.invalidateQueries({ queryKey: ["/api/streams/active"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update stream",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const deleteStreamMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/streams/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Stream deleted",
        description: "The stream has been deleted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/streams"] });
      queryClient.invalidateQueries({ queryKey: ["/api/streams/active"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete stream",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const handleGenerateKey = () => {
    generateKeyMutation.mutate();
  };
  
  const onSubmit = (data: CreateStreamFormValues) => {
    createStreamMutation.mutate(data);
  };
  
  const handleToggleStream = (id: number, currentState: boolean) => {
    toggleStreamMutation.mutate({ id, isActive: !currentState });
  };
  
  const handleDeleteStream = (id: number) => {
    if (confirm("Are you sure you want to delete this stream?")) {
      deleteStreamMutation.mutate(id);
    }
  };
  
  // Format date from timestamp
  const formatDate = (date: Date | string | null | undefined) => {
    if (!date) return "N/A";
    try {
      return format(new Date(date), "MMM d, yyyy h:mm a");
    } catch (err) {
      console.error("Date parsing error:", err);
      return "Invalid Date";
    }
  };

  return (
    <DashboardLayout title="Streams">
      <div className="mb-6 flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Stream Management</h1>
          <p className="text-muted-foreground">
            Create and manage your streaming channels
          </p>
        </div>
        
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => refetch()} disabled={isLoading}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Create Stream
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Stream</DialogTitle>
                <DialogDescription>
                  Set up a new streaming channel with a unique stream key
                </DialogDescription>
              </DialogHeader>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Stream Name</FormLabel>
                        <FormControl>
                          <Input placeholder="My Stream Channel" {...field} />
                        </FormControl>
                        <FormDescription>
                          A descriptive name for your stream
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="streamKey"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Stream Key</FormLabel>
                        <div className="flex gap-2">
                          <FormControl>
                            <Input 
                              placeholder="Stream key will be generated" 
                              {...field} 
                              readOnly 
                            />
                          </FormControl>
                          <Button
                            type="button"
                            variant="outline"
                            onClick={handleGenerateKey}
                            disabled={generateKeyMutation.isPending}
                          >
                            <Key className="h-4 w-4 mr-2" />
                            Generate
                          </Button>
                        </div>
                        <FormDescription>
                          Use this key in your streaming software
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <DialogFooter>
                    <Button 
                      type="submit" 
                      disabled={createStreamMutation.isPending || !form.formState.isValid}
                    >
                      Create Stream
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Your Streams</CardTitle>
          <CardDescription>
            Manage all your streaming channels from one place
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-8">
              <RefreshCw className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : streams && streams.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Stream Key</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead>Viewers</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {streams.map((stream) => (
                  <TableRow key={stream.id}>
                    <TableCell className="font-medium">{stream.name}</TableCell>
                    <TableCell>
                      <Badge className={stream.isActive ? "bg-green-500 hover:bg-green-600" : ""} variant={stream.isActive ? "default" : "secondary"}>
                        {stream.isActive ? "Live" : "Offline"}
                      </Badge>
                    </TableCell>
                    <TableCell className="font-mono text-xs">
                      {stream.streamKey.substring(0, 8)}...
                    </TableCell>
                    <TableCell>{formatDate(stream.startedAt || undefined)}</TableCell>
                    <TableCell>{stream.viewers || 0}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => handleToggleStream(stream.id, !!stream.isActive)}
                          disabled={toggleStreamMutation.isPending}
                        >
                          {stream.isActive ? (
                            <StopCircle className="h-4 w-4 text-destructive" />
                          ) : (
                            <Play className="h-4 w-4 text-green-600" />
                          )}
                        </Button>
                        
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              variant="outline"
                              size="icon"
                            >
                              <Share2 className="h-4 w-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="sm:max-w-md">
                            <DialogHeader>
                              <DialogTitle>Share Stream</DialogTitle>
                              <DialogDescription>
                                Use these options to embed your stream on your website
                              </DialogDescription>
                            </DialogHeader>
                            <div className="grid gap-4 py-4">
                              <div className="space-y-2">
                                <h3 className="text-sm font-medium">Embed Player</h3>
                                <Input
                                  readOnly
                                  className="font-mono text-xs"
                                  value={`<iframe src="${window.location.origin}/embed/${stream.streamKey}" width="640" height="360" frameborder="0" allow="autoplay" allowfullscreen></iframe>`}
                                  onClick={(e) => e.currentTarget.select()}
                                />
                              </div>
                              
                              <div className="space-y-2">
                                <h3 className="text-sm font-medium">Direct Stream URL</h3>
                                <Input
                                  readOnly
                                  className="font-mono text-xs"
                                  value={`${window.location.origin}/embed/${stream.streamKey}`}
                                  onClick={(e) => e.currentTarget.select()}
                                />
                              </div>
                              
                              <div className="space-y-2">
                                <h3 className="text-sm font-medium">WordPress Shortcode (WpStream)</h3>
                                <Input
                                  readOnly
                                  className="font-mono text-xs"
                                  value={`[wpstream_player key="${stream.streamKey}"]`}
                                  onClick={(e) => e.currentTarget.select()}
                                />
                              </div>
                            </div>
                            <DialogFooter className="flex-col items-start">
                              <h3 className="text-sm font-medium mb-2">Preview</h3>
                              <div className="rounded-md border bg-muted p-2 w-full">
                                <div className="responsive-iframe-container" style={{paddingTop: "60%"}}>
                                  <iframe 
                                    src={`${window.location.origin}/embed/${stream.streamKey}`} 
                                    frameBorder="0" 
                                    allowFullScreen 
                                  />
                                </div>
                              </div>
                              <p className="text-xs text-muted-foreground mt-2">
                                Note: This is a preview of how your stream will appear when embedded.
                              </p>
                            </DialogFooter>
                          </DialogContent>
                        </Dialog>
                        
                        <Button
                          variant="outline"
                          size="icon"
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => handleDeleteStream(stream.id)}
                          disabled={deleteStreamMutation.isPending}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-8">
              <h3 className="text-lg font-medium mb-2">No streams found</h3>
              <p className="text-gray-500 mb-4">
                You haven't created any streams yet. Create your first stream to get started.
              </p>
              <Button onClick={() => setDialogOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Create Stream
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </DashboardLayout>
  );
}
