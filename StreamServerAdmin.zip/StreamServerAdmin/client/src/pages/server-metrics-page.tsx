import { useState } from "react";
import { DashboardLayout } from "@/components/dashboard/layout";
import { ServerMetrics } from "@/components/dashboard/server-metrics";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery } from "@tanstack/react-query";
import { Server } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Legend,
  PieChart,
  Pie,
  Cell
} from "recharts";
import { Activity, AlertCircle, Clock } from "lucide-react";

export default function ServerMetricsPage() {
  const [selectedServerId, setSelectedServerId] = useState<number | null>(null);
  
  // Get all servers
  const { data: servers, isLoading: serversLoading } = useQuery<Server[]>({
    queryKey: ["/api/servers"],
  });
  
  // Set the first server as default selected server if not yet selected
  if (!selectedServerId && servers && servers.length > 0) {
    setSelectedServerId(servers[0].id);
  }
  
  // Get selected server data
  const { data: serverData, isLoading: serverDataLoading } = useQuery<Server>({
    queryKey: [`/api/rtmp/status/${selectedServerId}`],
    enabled: !!selectedServerId,
    refetchInterval: 10000, // refresh every 10 seconds
  });
  
  // Performance overview data for charts
  const performanceData = [
    { name: 'CPU', value: serverData?.cpuUsage || 0 },
    { name: 'Memory', value: serverData?.memoryUsage || 0 },
    { name: 'Disk', value: serverData?.diskUsage || 0 },
    { name: 'Network', value: serverData?.networkUsage || 0 }
  ];
  
  // Color scheme for charts
  const COLORS = ['#22c55e', '#3b82f6', '#f59e0b', '#ef4444'];
  
  // Format uptime for display
  const formatUptime = (seconds: number = 0) => {
    if (seconds === 0) return 'Not Running';
    
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    
    if (days > 0) {
      return `${days}d ${hours}h ${minutes}m`;
    } else if (hours > 0) {
      return `${hours}h ${minutes}m`;
    } else {
      return `${minutes}m`;
    }
  };
  
  return (
    <DashboardLayout title="Server Metrics">
      <div className="mb-6">
        <p className="text-muted-foreground">
          Monitor server performance metrics in real-time and analyze historical data to optimize your streaming infrastructure.
        </p>
      </div>
      
      {/* Server selector */}
      <div className="mb-6">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle>Server Selection</CardTitle>
            <CardDescription>
              Choose a server to view detailed metrics
            </CardDescription>
          </CardHeader>
          <CardContent>
            {serversLoading ? (
              <Skeleton className="h-10 w-full" />
            ) : (
              <Select 
                value={selectedServerId?.toString() || ""}
                onValueChange={(value) => setSelectedServerId(parseInt(value))}
              >
                <SelectTrigger className="w-full md:w-[300px]">
                  <SelectValue placeholder="Select a server" />
                </SelectTrigger>
                <SelectContent>
                  {servers?.map(server => (
                    <SelectItem key={server.id} value={server.id.toString()}>
                      {server.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </CardContent>
        </Card>
      </div>
      
      {/* Performance Overview */}
      {selectedServerId && (
        <div className="mb-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Performance charts */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Performance Overview</CardTitle>
              <CardDescription>Current server resource utilization</CardDescription>
            </CardHeader>
            <CardContent>
              {serverDataLoading ? (
                <Skeleton className="h-[300px] w-full" />
              ) : (
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={performanceData} margin={{ top: 20, right: 30, left: 5, bottom: 20 }}>
                      <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                      <XAxis dataKey="name" />
                      <YAxis domain={[0, 100]} label={{ value: 'Percentage (%)', angle: -90, position: 'insideLeft' }} />
                      <Tooltip formatter={(value) => [`${value}%`, 'Usage']} />
                      <Legend />
                      <Bar dataKey="value" name="Utilization">
                        {performanceData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </CardContent>
          </Card>
          
          {/* Server status info */}
          <Card>
            <CardHeader>
              <CardTitle>Server Status</CardTitle>
              <CardDescription>Current operational metrics</CardDescription>
            </CardHeader>
            <CardContent>
              {serverDataLoading ? (
                <div className="space-y-4">
                  <Skeleton className="h-6 w-3/4" />
                  <Skeleton className="h-6 w-full" />
                  <Skeleton className="h-6 w-2/3" />
                  <Skeleton className="h-6 w-5/6" />
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center">
                    <Activity className="mr-2 h-5 w-5 text-primary" />
                    <span className="text-sm font-medium">Status:</span>
                    <span className={`ml-auto text-sm font-medium ${serverData?.status === 'online' ? 'text-green-500' : 'text-orange-500'}`}>
                      {serverData?.status === 'online' ? 'Online' : 'Offline'}
                    </span>
                  </div>
                  
                  <div className="flex items-center">
                    <Clock className="mr-2 h-5 w-5 text-primary" />
                    <span className="text-sm font-medium">Uptime:</span>
                    <span className="ml-auto text-sm">
                      {formatUptime(serverData?.uptime || 0)}
                    </span>
                  </div>
                  
                  <div className="flex items-center">
                    <AlertCircle className="mr-2 h-5 w-5 text-primary" />
                    <span className="text-sm font-medium">Active Alerts:</span>
                    <span className="ml-auto text-sm">
                      {serverData?.cpuUsage && serverData.cpuUsage > 80 ? '1' : '0'}
                    </span>
                  </div>
                  
                  <div className="mt-4 pt-4 border-t">
                    <h4 className="text-sm font-medium mb-2">Resource Distribution</h4>
                    <div className="h-[150px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={performanceData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={60}
                            fill="#8884d8"
                            dataKey="value"
                            nameKey="name"
                            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                          >
                            {performanceData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip formatter={(value) => [`${value}%`, 'Usage']} />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}
      
      {/* Historical Metrics */}
      {selectedServerId && (
        <div className="mb-6">
          <Tabs defaultValue="realtime" className="w-full">
            <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 h-10 mb-6">
              <TabsTrigger value="realtime">Real-time Metrics</TabsTrigger>
              <TabsTrigger value="hourly">Hourly Analysis</TabsTrigger>
              <TabsTrigger value="daily">Daily Trends</TabsTrigger>
              <TabsTrigger value="weekly">Weekly Overview</TabsTrigger>
            </TabsList>
            
            <TabsContent value="realtime" className="mt-0">
              <ServerMetrics serverId={selectedServerId} />
            </TabsContent>
            
            <TabsContent value="hourly" className="mt-0">
              <Card>
                <CardHeader>
                  <CardTitle>Hourly Performance Analysis</CardTitle>
                  <CardDescription>Detailed resource usage over the past hour</CardDescription>
                </CardHeader>
                <CardContent>
                  <ServerMetrics serverId={selectedServerId} />
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="daily" className="mt-0">
              <Card>
                <CardHeader>
                  <CardTitle>Daily Performance Trends</CardTitle>
                  <CardDescription>Resource usage patterns over the past 24 hours</CardDescription>
                </CardHeader>
                <CardContent>
                  <ServerMetrics serverId={selectedServerId} />
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="weekly" className="mt-0">
              <Card>
                <CardHeader>
                  <CardTitle>Weekly Performance Overview</CardTitle>
                  <CardDescription>Long-term resource usage analysis for the past week</CardDescription>
                </CardHeader>
                <CardContent>
                  <ServerMetrics serverId={selectedServerId} />
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      )}
    </DashboardLayout>
  );
}