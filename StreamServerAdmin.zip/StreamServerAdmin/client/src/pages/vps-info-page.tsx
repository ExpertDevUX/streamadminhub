import { DashboardLayout } from "@/components/dashboard/layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Loader2, Server, HardDrive, Cpu, MemoryStick, Network, Link as LinkIcon } from "lucide-react";
import { useEffect, useState } from "react";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface ServerResource {
  name: string;
  value: number;
  icon: React.ReactNode;
  color: string;
}

interface NetworkInfo {
  ip: string;
  hostname: string;
  macAddress: string;
  uploadSpeed: string;
  downloadSpeed: string;
  latency: string;
}

export default function VpsInfoPage() {
  const { toast } = useToast();
  const [networkInfo, setNetworkInfo] = useState<NetworkInfo>({
    ip: "-",
    hostname: "-",
    macAddress: "-",
    uploadSpeed: "0 Mbps",
    downloadSpeed: "0 Mbps",
    latency: "0 ms"
  });

  // Fetch server metrics
  const { data: serverMetrics, isLoading: isLoadingMetrics } = useQuery({
    queryKey: ["/api/servers/1/metrics"],
    queryFn: async () => {
      try {
        const res = await apiRequest("GET", "/api/servers/1/metrics");
        return await res.json();
      } catch (error) {
        console.error("Error fetching server metrics:", error);
        return {
          cpu: 0,
          memory: 0,
          disk: 0,
          network: 0,
          uptime: 0
        };
      }
    },
    refetchInterval: 10000 // Refresh every 10 seconds
  });

  // Basic hardware info
  const { data: serverInfo, isLoading: isLoadingInfo } = useQuery({
    queryKey: ["/api/servers/1"],
    queryFn: async () => {
      try {
        const res = await apiRequest("GET", "/api/servers/1");
        return await res.json();
      } catch (error) {
        console.error("Error fetching server info:", error);
        return {
          name: "Default RTMP Server",
          host: "localhost",
          cpuModel: "Unknown CPU",
          memoryTotal: "0 GB",
          diskTotal: "0 GB",
          os: "Unknown OS"
        };
      }
    }
  });

  // Simulate network testing
  const runNetworkTest = () => {
    toast({
      title: "Network Test Started",
      description: "Testing connection speed and latency..."
    });
    
    // Simulate progress
    const testDuration = 5000; // 5 seconds
    const steps = 10;
    const stepTime = testDuration / steps;
    
    for (let i = 1; i <= steps; i++) {
      setTimeout(() => {
        if (i === steps) {
          // Test complete, update with "results"
          setNetworkInfo({
            ip: "198.51.100." + Math.floor(Math.random() * 255),
            hostname: serverInfo?.host || "localhost",
            macAddress: "00:1A:2B:" + Math.floor(Math.random() * 100) + ":" + Math.floor(Math.random() * 100) + ":" + Math.floor(Math.random() * 100),
            uploadSpeed: (Math.random() * 10).toFixed(2) + " Mbps",
            downloadSpeed: (Math.random() * 100).toFixed(2) + " Mbps",
            latency: Math.floor(Math.random() * 50) + " ms"
          });
          
          toast({
            title: "Network Test Complete",
            description: "Connection tests finished successfully."
          });
        }
      }, i * stepTime);
    }
  };

  // Set default resources
  const resources: ServerResource[] = [
    {
      name: "CPU Usage",
      value: serverMetrics?.cpu || 0,
      icon: <Cpu className="h-4 w-4" />,
      color: "bg-blue-500"
    },
    {
      name: "Memory Usage",
      value: serverMetrics?.memory || 0,
      icon: <MemoryStick className="h-4 w-4" />,
      color: "bg-green-500"
    },
    {
      name: "Disk Usage",
      value: serverMetrics?.disk || 0,
      icon: <HardDrive className="h-4 w-4" />,
      color: "bg-amber-500"
    },
    {
      name: "Network Usage",
      value: serverMetrics?.network || 0,
      icon: <Network className="h-4 w-4" />,
      color: "bg-purple-500"
    }
  ];

  // Format uptime
  const formatUptime = (seconds: number) => {
    if (!seconds) return "0 minutes";
    
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    
    const parts = [];
    if (days > 0) parts.push(`${days} day${days !== 1 ? 's' : ''}`);
    if (hours > 0) parts.push(`${hours} hour${hours !== 1 ? 's' : ''}`);
    if (minutes > 0) parts.push(`${minutes} minute${minutes !== 1 ? 's' : ''}`);
    
    return parts.join(', ');
  };

  return (
    <DashboardLayout title="VPS Information">
      <div className="container mx-auto py-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Server Information */}
          <div className="lg:col-span-8 space-y-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-xl flex items-center">
                  <Server className="mr-2 h-5 w-5 text-primary" />
                  Server Information
                </CardTitle>
                <CardDescription>
                  Hardware and system information for your VPS
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoadingInfo ? (
                  <div className="flex justify-center py-6">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="text-sm font-medium text-gray-500">Server Name</h4>
                        <p className="mt-1 text-lg font-medium">{serverInfo?.name || "Default Server"}</p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-gray-500">Host</h4>
                        <p className="mt-1 text-lg font-medium">{serverInfo?.host || "localhost"}</p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-gray-500">CPU Model</h4>
                        <p className="mt-1 text-lg font-medium">{serverInfo?.cpuModel || "Intel Xeon (Default)"}</p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-gray-500">Total Memory</h4>
                        <p className="mt-1 text-lg font-medium">{serverInfo?.memoryTotal || "4 GB (Default)"}</p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-gray-500">Total Disk</h4>
                        <p className="mt-1 text-lg font-medium">{serverInfo?.diskTotal || "100 GB (Default)"}</p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-gray-500">Operating System</h4>
                        <p className="mt-1 text-lg font-medium">{serverInfo?.os || "Linux (Default)"}</p>
                      </div>
                    </div>

                    <Separator />

                    <div>
                      <h3 className="text-lg font-medium mb-4">Current Resource Usage</h3>
                      
                      {isLoadingMetrics ? (
                        <div className="flex justify-center py-6">
                          <Loader2 className="h-6 w-6 animate-spin text-primary" />
                        </div>
                      ) : (
                        <div className="space-y-4">
                          {resources.map((resource, i) => (
                            <div key={i} className="space-y-2">
                              <div className="flex justify-between items-center">
                                <div className="flex items-center">
                                  <div className={`w-6 h-6 rounded-full flex items-center justify-center ${resource.value > 80 ? 'bg-red-100 text-red-600' : 'bg-primary/10 text-primary'}`}>
                                    {resource.icon}
                                  </div>
                                  <span className="ml-2 text-sm font-medium">{resource.name}</span>
                                </div>
                                <span className="font-medium text-sm">{resource.value}%</span>
                              </div>
                              <Progress value={resource.value} className="h-2" indicatorClassName={resource.color} />
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                    
                    <div>
                      <h4 className="text-sm font-medium text-gray-500">Uptime</h4>
                      <p className="mt-1 text-lg font-medium">{formatUptime(serverMetrics?.uptime || 0)}</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Network Information */}
          <div className="lg:col-span-4 space-y-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-xl flex items-center">
                  <LinkIcon className="mr-2 h-5 w-5 text-primary" />
                  Network Information
                </CardTitle>
                <CardDescription>
                  Connectivity and network details
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-medium text-gray-500">IP Address</h4>
                    <p className="mt-1 font-medium">{networkInfo.ip}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Hostname</h4>
                    <p className="mt-1 font-medium">{networkInfo.hostname}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-500">MAC Address</h4>
                    <p className="mt-1 font-medium">{networkInfo.macAddress}</p>
                  </div>

                  <Separator />
                  
                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Upload Speed</h4>
                    <p className="mt-1 font-medium">{networkInfo.uploadSpeed}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Download Speed</h4>
                    <p className="mt-1 font-medium">{networkInfo.downloadSpeed}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Latency</h4>
                    <p className="mt-1 font-medium">{networkInfo.latency}</p>
                  </div>

                  <Button 
                    variant="outline" 
                    className="w-full mt-4"
                    onClick={runNetworkTest}
                  >
                    Run Network Test
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}