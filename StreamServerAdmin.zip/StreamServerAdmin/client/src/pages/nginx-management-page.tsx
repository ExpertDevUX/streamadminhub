import { useState } from "react";
import { DashboardLayout } from "@/components/dashboard/layout";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { 
  AlertCircle, 
  CheckCircle2, 
  AlertTriangle, 
  RefreshCw, 
  Download, 
  Trash2, 
  Wrench,
  Settings
} from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Form, 
  FormControl, 
  FormDescription, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage
} from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

interface NginxStatus {
  installed: boolean;
  running: boolean;
  rtmpModuleInstalled: boolean;
  configValid: boolean;
}

// Port configuration schema
const portConfigSchema = z.object({
  rtmpPort: z.coerce
    .number()
    .int()
    .min(1024, "Port must be at least 1024")
    .max(65535, "Port must be at most 65535"),
  httpPort: z.coerce
    .number()
    .int()
    .min(1, "Port must be at least 1")
    .max(65535, "Port must be at most 65535"),
});

type PortConfigFormValues = z.infer<typeof portConfigSchema>;

export default function NginxManagementPage() {
  const { toast } = useToast();
  const [confirmDialogOpen, setConfirmDialogOpen] = useState(false);
  const [actionType, setActionType] = useState<"install" | "repair" | "uninstall" | null>(null);
  const [showRtmpPortDialog, setShowRtmpPortDialog] = useState(false);
  const [showHttpPortDialog, setShowHttpPortDialog] = useState(false);
  
  const { data: nginxStatus, isLoading, refetch } = useQuery<NginxStatus>({
    queryKey: ["/api/nginx/status"],
    refetchInterval: 10000, // Auto-refresh every 10 seconds
  });

  const rtmpPortForm = useForm<PortConfigFormValues>({
    resolver: zodResolver(portConfigSchema),
    defaultValues: {
      rtmpPort: 1935,
    },
  });

  const httpPortForm = useForm<PortConfigFormValues>({
    resolver: zodResolver(portConfigSchema),
    defaultValues: {
      httpPort: 80,
    },
  });
  
  const changeRtmpPortMutation = useMutation({
    mutationFn: async (data: { port: number }) => {
      const res = await apiRequest("POST", "/api/nginx/change-rtmp-port", data);
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "RTMP Port Changed",
        description: data.message,
        variant: data.success ? "default" : "destructive",
      });
      setShowRtmpPortDialog(false);
      refetch();
    },
    onError: (error: Error) => {
      toast({
        title: "Port Change Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const changeHttpPortMutation = useMutation({
    mutationFn: async (data: { port: number }) => {
      const res = await apiRequest("POST", "/api/nginx/change-http-port", data);
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "HTTP Port Changed",
        description: data.message,
        variant: data.success ? "default" : "destructive",
      });
      setShowHttpPortDialog(false);
      refetch();
    },
    onError: (error: Error) => {
      toast({
        title: "Port Change Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const onSubmitRtmpPort = (data: PortConfigFormValues) => {
    changeRtmpPortMutation.mutate({ port: data.rtmpPort });
  };
  
  const onSubmitHttpPort = (data: PortConfigFormValues) => {
    changeHttpPortMutation.mutate({ port: data.httpPort });
  };
  
  const installMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/nginx/install");
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "NGINX Installation",
        description: data.message,
        variant: data.success ? "default" : "destructive",
      });
      refetch();
    },
    onError: (error: Error) => {
      toast({
        title: "Installation Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const repairMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/nginx/repair");
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "NGINX Repair",
        description: data.message,
        variant: data.success ? "default" : "destructive",
      });
      refetch();
    },
    onError: (error: Error) => {
      toast({
        title: "Repair Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const uninstallMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/nginx/uninstall");
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "NGINX Uninstallation",
        description: data.message,
        variant: data.success ? "default" : "destructive",
      });
      refetch();
    },
    onError: (error: Error) => {
      toast({
        title: "Uninstallation Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const handleAction = (type: "install" | "repair" | "uninstall") => {
    if (type === "uninstall") {
      setActionType("uninstall");
      setConfirmDialogOpen(true);
      return;
    }
    
    executeAction(type);
  };
  
  const executeAction = (type: "install" | "repair" | "uninstall") => {
    setConfirmDialogOpen(false);
    
    switch (type) {
      case "install":
        installMutation.mutate();
        break;
      case "repair":
        repairMutation.mutate();
        break;
      case "uninstall":
        uninstallMutation.mutate();
        break;
    }
  };
  
  const getStatusIndicator = (status: boolean | undefined, loading: boolean) => {
    if (loading) return <RefreshCw className="h-5 w-5 animate-spin text-primary" />;
    if (status === undefined) return <AlertCircle className="h-5 w-5 text-gray-400" />;
    return status ? 
      <CheckCircle2 className="h-5 w-5 text-green-500" /> : 
      <AlertTriangle className="h-5 w-5 text-amber-500" />;
  };
  
  return (
    <DashboardLayout title="NGINX Management">
      <div className="mb-6">
        <h1 className="text-2xl font-bold tracking-tight">NGINX Server Management</h1>
        <p className="text-muted-foreground">
          Manage your NGINX server with RTMP module for streaming
        </p>
      </div>
      
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>NGINX Status</CardTitle>
            <CardDescription>
              Current status of your NGINX installation
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-8">
                <RefreshCw className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : nginxStatus ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="font-medium">NGINX Installed</span>
                  <div className="flex items-center">
                    {getStatusIndicator(nginxStatus.installed, isLoading)}
                    <span className="ml-2">
                      {nginxStatus.installed ? "Yes" : "No"}
                    </span>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="font-medium">NGINX Running</span>
                  <div className="flex items-center">
                    {getStatusIndicator(nginxStatus.running, isLoading)}
                    <span className="ml-2">
                      {nginxStatus.running ? "Yes" : "No"}
                    </span>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="font-medium">RTMP Module Installed</span>
                  <div className="flex items-center">
                    {getStatusIndicator(nginxStatus.rtmpModuleInstalled, isLoading)}
                    <span className="ml-2">
                      {nginxStatus.rtmpModuleInstalled ? "Yes" : "No"}
                    </span>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="font-medium">Configuration Valid</span>
                  <div className="flex items-center">
                    {getStatusIndicator(nginxStatus.configValid, isLoading)}
                    <span className="ml-2">
                      {nginxStatus.configValid ? "Yes" : "No"}
                    </span>
                  </div>
                </div>
              </div>
            ) : (
              <Alert variant="destructive" className="mt-4">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>
                  Unable to fetch NGINX status information
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button 
              variant="outline" 
              onClick={() => refetch()}
              disabled={isLoading}
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
              Refresh Status
            </Button>
          </CardFooter>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>NGINX Actions</CardTitle>
            <CardDescription>
              Manage your NGINX server installation
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-medium mb-2">Installation</h3>
                <p className="text-sm text-muted-foreground mb-2">
                  Install NGINX with RTMP module for video streaming
                </p>
                <Button
                  onClick={() => handleAction("install")}
                  disabled={installMutation.isPending || (nginxStatus?.installed && nginxStatus?.rtmpModuleInstalled)}
                  className="w-full"
                >
                  {installMutation.isPending ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Installing...
                    </>
                  ) : (
                    <>
                      <Download className="h-4 w-4 mr-2" />
                      Install NGINX with RTMP
                    </>
                  )}
                </Button>
              </div>
              
              <div>
                <h3 className="text-sm font-medium mb-2">Repair</h3>
                <p className="text-sm text-muted-foreground mb-2">
                  Fix common NGINX configuration issues and restart the service
                </p>
                <Button
                  onClick={() => handleAction("repair")}
                  disabled={repairMutation.isPending || !nginxStatus?.installed}
                  variant="secondary"
                  className="w-full"
                >
                  {repairMutation.isPending ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Repairing...
                    </>
                  ) : (
                    <>
                      <Wrench className="h-4 w-4 mr-2" />
                      Repair NGINX
                    </>
                  )}
                </Button>
              </div>
              
              <div>
                <h3 className="text-sm font-medium mb-2">Uninstallation</h3>
                <p className="text-sm text-muted-foreground mb-2">
                  Completely remove NGINX and all its configuration files
                </p>
                <Button
                  onClick={() => handleAction("uninstall")}
                  disabled={uninstallMutation.isPending || !nginxStatus?.installed}
                  variant="destructive"
                  className="w-full"
                >
                  {uninstallMutation.isPending ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Uninstalling...
                    </>
                  ) : (
                    <>
                      <Trash2 className="h-4 w-4 mr-2" />
                      Uninstall NGINX
                    </>
                  )}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Port Configuration</CardTitle>
          <CardDescription>
            Configure NGINX server ports for HTTP and RTMP traffic
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 sm:grid-cols-2">
            <div className="space-y-2">
              <h3 className="text-sm font-medium">RTMP Port</h3>
              <p className="text-sm text-muted-foreground">
                Configure the port used for RTMP streaming (default: 1935)
              </p>
              <Button 
                variant="outline" 
                onClick={() => setShowRtmpPortDialog(true)}
                disabled={!nginxStatus?.installed || changeRtmpPortMutation.isPending}
                className="mt-2 w-full"
              >
                <Settings className="h-4 w-4 mr-2" />
                Change RTMP Port
              </Button>
            </div>
            
            <div className="space-y-2">
              <h3 className="text-sm font-medium">HTTP Port</h3>
              <p className="text-sm text-muted-foreground">
                Configure the port used for HTTP/HLS streaming (default: 80)
              </p>
              <Button 
                variant="outline" 
                onClick={() => setShowHttpPortDialog(true)}
                disabled={!nginxStatus?.installed || changeHttpPortMutation.isPending}
                className="mt-2 w-full"
              >
                <Settings className="h-4 w-4 mr-2" />
                Change HTTP Port
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Troubleshooting</CardTitle>
          <CardDescription>
            Common issues and solutions for NGINX server
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-1">
              <AccordionTrigger>NGINX fails to start with "unknown directive" errors</AccordionTrigger>
              <AccordionContent>
                <p>This usually indicates that the RTMP module is not correctly installed or configured. Try the following:</p>
                <ol className="list-decimal pl-5 space-y-2 mt-2">
                  <li>Use the "Repair NGINX" button above to automatically fix configuration issues</li>
                  <li>Check if the RTMP module is properly installed in the NGINX configuration</li>
                  <li>Ensure the RTMP directives are placed in the correct context in the configuration files</li>
                </ol>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-2">
              <AccordionTrigger>Cannot access RTMP streams</AccordionTrigger>
              <AccordionContent>
                <p>If you cannot access RTMP streams through your server, check the following:</p>
                <ol className="list-decimal pl-5 space-y-2 mt-2">
                  <li>Verify that port 1935 (RTMP) is open in your firewall</li>
                  <li>Check that the NGINX service is running properly</li>
                  <li>Ensure the correct stream key is being used in your streaming software</li>
                  <li>Check the NGINX error logs for any specific errors</li>
                </ol>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-3">
              <AccordionTrigger>HLS streaming not working</AccordionTrigger>
              <AccordionContent>
                <p>If HLS (HTTP Live Streaming) is not working properly, try the following:</p>
                <ol className="list-decimal pl-5 space-y-2 mt-2">
                  <li>Verify that the HLS path (/var/www/html/hls) exists and has proper permissions</li>
                  <li>Check that the HLS directives are correctly configured in the NGINX RTMP configuration</li>
                  <li>Ensure that the HTTP server is properly configured to serve the HLS content</li>
                  <li>Use the "Repair NGINX" feature to fix common configuration issues</li>
                </ol>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-4">
              <AccordionTrigger>Permission issues with NGINX</AccordionTrigger>
              <AccordionContent>
                <p>If NGINX is reporting permission errors, try the following:</p>
                <ol className="list-decimal pl-5 space-y-2 mt-2">
                  <li>Check that the NGINX worker process has proper permissions to access required directories</li>
                  <li>Ensure log directories are properly created and have write permissions</li>
                  <li>Check SELinux settings if you're on a system that uses it</li>
                  <li>Use the "Repair NGINX" feature which includes permission fixes</li>
                </ol>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>
      
      {/* Confirmation Dialog */}
      <Dialog open={confirmDialogOpen} onOpenChange={setConfirmDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Action</DialogTitle>
            <DialogDescription>
              {actionType === "uninstall" ? (
                "Are you sure you want to uninstall NGINX? This will remove all NGINX configurations and might affect your streaming capabilities."
              ) : actionType === "repair" ? (
                "This will attempt to fix NGINX configuration issues and restart the service. Continue?"
              ) : (
                "Are you sure you want to proceed with this action?"
              )}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirmDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              variant={actionType === "uninstall" ? "destructive" : "default"}
              onClick={() => actionType && executeAction(actionType)}
            >
              Confirm
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* RTMP Port Configuration Dialog */}
      <Dialog open={showRtmpPortDialog} onOpenChange={setShowRtmpPortDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Change RTMP Port</DialogTitle>
            <DialogDescription>
              Configure the port used for RTMP streaming. Default is 1935.
            </DialogDescription>
          </DialogHeader>
          <Form {...rtmpPortForm}>
            <form onSubmit={rtmpPortForm.handleSubmit(onSubmitRtmpPort)} className="space-y-6">
              <FormField
                control={rtmpPortForm.control}
                name="rtmpPort"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>RTMP Port</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        placeholder="1935" 
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      Enter a port number between 1024 and 65535. Make sure this port is not in use by other services.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setShowRtmpPortDialog(false)}
                  disabled={changeRtmpPortMutation.isPending}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={changeRtmpPortMutation.isPending}
                >
                  {changeRtmpPortMutation.isPending ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Changing...
                    </>
                  ) : (
                    "Save Changes"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      {/* HTTP Port Configuration Dialog */}
      <Dialog open={showHttpPortDialog} onOpenChange={setShowHttpPortDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Change HTTP Port</DialogTitle>
            <DialogDescription>
              Configure the port used for HTTP/HLS streaming. Default is 80.
            </DialogDescription>
          </DialogHeader>
          <Form {...httpPortForm}>
            <form onSubmit={httpPortForm.handleSubmit(onSubmitHttpPort)} className="space-y-6">
              <FormField
                control={httpPortForm.control}
                name="httpPort"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>HTTP Port</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        placeholder="80" 
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      Standard HTTP ports are 80 and 8080. Using ports below 1024 typically requires root privileges.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setShowHttpPortDialog(false)}
                  disabled={changeHttpPortMutation.isPending}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={changeHttpPortMutation.isPending}
                >
                  {changeHttpPortMutation.isPending ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Changing...
                    </>
                  ) : (
                    "Save Changes"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}