import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Activity } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Video, 
  AlertTriangle,
  UserPlus,
  Settings,
  Activity as ActivityIcon
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export function ActivityLog() {
  const { data: activities, isLoading, fetchNextPage, hasNextPage } = useQuery<Activity[]>({
    queryKey: ["/api/activities"],
  });
  
  // Get the appropriate icon for the activity type
  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'stream_started':
      case 'stream_stopped':
      case 'stream_created':
      case 'stream_deleted':
        return <Video className="text-primary" />;
      case 'bandwidth_warning':
      case 'server_warning':
        return <AlertTriangle className="text-amber-500" />;
      case 'user_added':
      case 'user_updated':
      case 'user_deleted':
        return <UserPlus className="text-primary" />;
      case 'server_install':
      case 'server_start':
      case 'server_stop':
      case 'server_config_updated':
        return <Settings className="text-green-500" />;
      default:
        return <ActivityIcon className="text-primary" />;
    }
  };
  
  // Format the timestamp as relative time
  const formatTimestamp = (timestamp: Date) => {
    return formatDistanceToNow(new Date(timestamp), { addSuffix: true });
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flow-root">
            <ul className="-mb-8">
              {[1, 2, 3, 4].map((i) => (
                <li key={i}>
                  <div className="relative pb-8">
                    <span className="absolute top-5 left-5 -ml-px h-full w-0.5 bg-gray-200" aria-hidden="true"></span>
                    <div className="relative flex items-start space-x-3">
                      <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center">
                        <Skeleton className="h-6 w-6 rounded-full" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <Skeleton className="h-5 w-40 mb-1" />
                        <Skeleton className="h-4 w-64 mb-1" />
                        <Skeleton className="h-3 w-20" />
                      </div>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Activity</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flow-root">
          <ul className="-mb-8">
            {activities && activities.map((activity, idx) => (
              <li key={activity.id}>
                <div className="relative pb-8">
                  {idx < activities.length - 1 && (
                    <span className="absolute top-5 left-5 -ml-px h-full w-0.5 bg-gray-200" aria-hidden="true"></span>
                  )}
                  <div className="relative flex items-start space-x-3">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                      {getActivityIcon(activity.type)}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-medium text-gray-900">
                        {activity.type.split('_').map(word => 
                          word.charAt(0).toUpperCase() + word.slice(1)
                        ).join(' ')}
                      </div>
                      <p className="text-sm text-gray-500">{activity.message}</p>
                      <div className="mt-1 text-xs text-gray-400">
                        {formatTimestamp(activity.timestamp)}
                      </div>
                    </div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </CardContent>
      <CardFooter className="px-6 py-4 bg-gray-50 rounded-b-lg flex justify-center">
        <Button variant="link" className="text-primary text-sm font-medium">
          Load More Activity
        </Button>
      </CardFooter>
    </Card>
  );
}
