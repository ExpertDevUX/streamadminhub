import { useEffect, useState, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Legend
} from "recharts";
import { Server } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "@/hooks/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

interface ServerMetricsProps {
  serverId: number;
}

interface MetricDataPoint {
  timestamp: number;
  cpu: number;
  memory: number;
  disk: number;
  network: number;
}

const MAX_DATA_POINTS = 20;

export function ServerMetrics({ serverId }: ServerMetricsProps) {
  const [selectedTimeFrame, setSelectedTimeFrame] = useState<string>("realtime");
  const [metricsData, setMetricsData] = useState<MetricDataPoint[]>([]);
  const [wsConnected, setWsConnected] = useState<boolean>(false);
  const [wsError, setWsError] = useState<string | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  
  // Colors for the chart lines
  const colors = {
    cpu: "#22c55e",     // Green
    memory: "#3b82f6",  // Blue
    disk: "#f59e0b",    // Amber
    network: "#ef4444"  // Red
  };
  
  // Get current server information
  const { data: server, isLoading } = useQuery<Server>({
    queryKey: [`/api/rtmp/status/${serverId}`],
    refetchInterval: 10000, // Refresh every 10 seconds
  });
  
  // Fetch historical data based on time frame
  useEffect(() => {
    const fetchHistoricalData = async () => {
      if (selectedTimeFrame === "realtime") return;
      
      try {
        let endpoint = `/api/rtmp/metrics/${serverId}`;
        switch (selectedTimeFrame) {
          case "hour":
            endpoint += "?period=hour";
            break;
          case "day":
            endpoint += "?period=day";
            break;
          case "week":
            endpoint += "?period=week";
            break;
        }
        
        const response = await apiRequest("GET", endpoint);
        const data = await response.json();
        setMetricsData(data);
      } catch (error) {
        console.error("Failed to fetch historical data", error);
        toast({
          title: "Error",
          description: "Failed to load historical metrics data",
          variant: "destructive",
        });
      }
    };
    
    fetchHistoricalData();
  }, [serverId, selectedTimeFrame]);
  
  // Setup WebSocket connection for real-time updates
  useEffect(() => {
    if (selectedTimeFrame !== "realtime") {
      // Close WebSocket connection if not in real-time mode
      if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
        wsRef.current.close();
        setWsConnected(false);
      }
      return;
    }
    
    // Setup WebSocket connection for real-time metrics
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    try {
      console.log("Connecting to WebSocket:", wsUrl);
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;
      
      ws.onopen = () => {
        console.log("WebSocket connected");
        setWsConnected(true);
        setWsError(null);
      };
      
      ws.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data);
          
          if (message.type === 'serverMetrics') {
            const newData = message.data;
            
            // Create a new data point with the received metrics
            const newDataPoint: MetricDataPoint = {
              timestamp: newData.timestamp,
              cpu: newData.cpu || 0,
              memory: newData.memory || 0,
              disk: newData.disk || 0,
              network: newData.network || 0
            };
            
            // Update metrics data
            setMetricsData(prevData => {
              // Clone previous data and add new point
              const updatedData = [...prevData, newDataPoint];
              
              // Keep only the last MAX_DATA_POINTS
              if (updatedData.length > MAX_DATA_POINTS) {
                return updatedData.slice(updatedData.length - MAX_DATA_POINTS);
              }
              
              return updatedData;
            });
          }
        } catch (error) {
          console.error("Failed to parse WebSocket message:", error);
        }
      };
      
      ws.onerror = (error) => {
        console.error("WebSocket error:", error);
        setWsError("Failed to connect to server. Real-time updates are not available.");
        setWsConnected(false);
      };
      
      ws.onclose = () => {
        console.log("WebSocket connection closed");
        setWsConnected(false);
      };
    } catch (error) {
      console.error("WebSocket connection error:", error);
      setWsError(`Failed to connect to WebSocket: ${error instanceof Error ? error.message : String(error)}`);
      setWsConnected(false);
    }
    
    // Clean up WebSocket connection when unmounting or changing modes
    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [selectedTimeFrame]);
  
  // Fallback to server API data when WebSocket is not available
  useEffect(() => {
    if (selectedTimeFrame !== "realtime" || wsConnected || !server) return;
    
    // Add new data point from API data if WebSocket is not connected
    const newDataPoint: MetricDataPoint = {
      timestamp: Date.now(),
      cpu: server.cpuUsage || 0,
      memory: server.memoryUsage || 0,
      disk: server.diskUsage || 0,
      network: server.networkUsage || 0
    };
    
    setMetricsData(prevData => {
      // Clone previous data and add new point
      const newData = [...prevData, newDataPoint];
      
      // Keep only the last MAX_DATA_POINTS
      if (newData.length > MAX_DATA_POINTS) {
        return newData.slice(newData.length - MAX_DATA_POINTS);
      }
      
      return newData;
    });
    
    // Set up interval to fetch new data
    const intervalId = setInterval(() => {
      // This will trigger a re-fetch of the server data through the query
    }, 5000);
    
    return () => clearInterval(intervalId);
  }, [server, selectedTimeFrame, wsConnected]);
  
  // Format timestamp for tooltips
  const formatTimestamp = (timestamp: number) => {
    if (selectedTimeFrame === "realtime") {
      return new Date(timestamp).toLocaleTimeString();
    } else if (selectedTimeFrame === "hour") {
      return new Date(timestamp).toLocaleTimeString();
    } else if (selectedTimeFrame === "day") {
      return new Date(timestamp).toLocaleString();
    } else {
      return new Date(timestamp).toLocaleDateString();
    }
  };
  
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Server Metrics</CardTitle>
        </CardHeader>
        <CardContent className="h-80 flex items-center justify-center">
          <Skeleton className="h-full w-full" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Server Metrics</CardTitle>
        <div className="flex gap-2">
          <Tabs 
            defaultValue="realtime"
            value={selectedTimeFrame}
            onValueChange={setSelectedTimeFrame}
            className="w-full"
          >
            <TabsList className="grid grid-cols-4 h-8">
              <TabsTrigger value="realtime" className="text-xs">Real-time</TabsTrigger>
              <TabsTrigger value="hour" className="text-xs">Hour</TabsTrigger>
              <TabsTrigger value="day" className="text-xs">Day</TabsTrigger>
              <TabsTrigger value="week" className="text-xs">Week</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </CardHeader>
      <CardContent>
        {wsError && selectedTimeFrame === "realtime" && (
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Connection Error</AlertTitle>
            <AlertDescription>{wsError}</AlertDescription>
          </Alert>
        )}
        
        <div className="h-[350px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={metricsData}
              margin={{ top: 5, right: 30, left: 5, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis 
                dataKey="timestamp" 
                tickFormatter={formatTimestamp}
                tick={{ fontSize: 12 }}
                minTickGap={50}
              />
              <YAxis tick={{ fontSize: 12 }} domain={[0, 100]} />
              <Tooltip 
                labelFormatter={formatTimestamp} 
                formatter={(value: number) => [`${value}%`, ""]}
              />
              <Legend />
              <Line
                type="monotone"
                dataKey="cpu"
                name="CPU Usage"
                stroke={colors.cpu}
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 6 }}
                isAnimationActive={false}
              />
              <Line
                type="monotone"
                dataKey="memory"
                name="Memory Usage"
                stroke={colors.memory}
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 6 }}
                isAnimationActive={false}
              />
              <Line
                type="monotone"
                dataKey="disk"
                name="Disk Usage"
                stroke={colors.disk}
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 6 }}
                isAnimationActive={false}
              />
              <Line
                type="monotone"
                dataKey="network"
                name="Network Usage"
                stroke={colors.network}
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 6 }}
                isAnimationActive={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
        
        {metricsData.length === 0 && selectedTimeFrame !== "realtime" && (
          <div className="absolute inset-0 flex items-center justify-center bg-background/80">
            <p className="text-sm text-muted-foreground">No historical data available for the selected period</p>
          </div>
        )}
        
        {metricsData.length === 0 && selectedTimeFrame === "realtime" && (
          <div className="absolute inset-0 flex items-center justify-center bg-background/80">
            <p className="text-sm text-muted-foreground">Waiting for real-time data...</p>
          </div>
        )}
      </CardContent>
      <CardFooter className="text-xs text-muted-foreground flex justify-between items-center">
        <span>Data updates every 5 seconds in real-time mode</span>
        {selectedTimeFrame === "realtime" && (
          <span className="flex items-center">
            <span className={`h-2 w-2 rounded-full mr-2 ${wsConnected ? 'bg-green-500' : 'bg-red-500'}`}></span>
            {wsConnected ? "WebSocket connected" : "WebSocket disconnected"}
          </span>
        )}
      </CardFooter>
    </Card>
  );
}