import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Copy, Check, Code, Monitor } from "lucide-react";
import type { Stream } from "@shared/schema";

interface IframeWidgetProps {
  stream: Stream;
  baseUrl: string;
}

export function IframeWidget({ stream, baseUrl }: IframeWidgetProps) {
  const [copied, setCopied] = useState<string | null>(null);
  const [embedCode, setEmbedCode] = useState({
    iframe: "",
    shortcode: "",
    widget: ""
  });
  
  useEffect(() => {
    // Generate embed codes when stream data changes
    const iframeCode = `<iframe 
  src="${baseUrl}/embed/${stream.streamKey}" 
  width="100%" 
  height="480" 
  frameborder="0" 
  allowfullscreen
></iframe>`;

    const shortcodeCode = `[wpstream_embed stream_key="${stream.streamKey}"]`;
    
    const widgetCode = `<div class="wpstream-widget" 
  data-stream-key="${stream.streamKey}" 
  data-width="100%" 
  data-height="480"
></div>
<script src="${baseUrl}/widget.js"></script>`;
    
    setEmbedCode({
      iframe: iframeCode,
      shortcode: shortcodeCode,
      widget: widgetCode
    });
  }, [stream, baseUrl]);
  
  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopied(type);
    setTimeout(() => setCopied(null), 2000);
  };
  
  return (
    <Card className="shadow-sm">
      <CardHeader>
        <CardTitle>Embed Options</CardTitle>
        <CardDescription>
          Choose how you want to embed your stream on websites
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="iframe">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="iframe">
              <Monitor className="mr-2 h-4 w-4" />
              Iframe
            </TabsTrigger>
            <TabsTrigger value="shortcode">
              <Code className="mr-2 h-4 w-4" />
              Shortcode
            </TabsTrigger>
            <TabsTrigger value="widget">
              <Code className="mr-2 h-4 w-4" />
              Widget
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="iframe" className="mt-4">
            <div className="space-y-4">
              <Textarea 
                value={embedCode.iframe} 
                readOnly 
                className="h-32 font-mono text-sm"
              />
              <div className="flex items-center justify-between">
                <p className="text-sm text-muted-foreground">
                  Use this code to embed your stream in any website with an iframe.
                </p>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => copyToClipboard(embedCode.iframe, 'iframe')}
                >
                  {copied === 'iframe' ? (
                    <>
                      <Check className="mr-2 h-4 w-4" />
                      Copied
                    </>
                  ) : (
                    <>
                      <Copy className="mr-2 h-4 w-4" />
                      Copy
                    </>
                  )}
                </Button>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="shortcode" className="mt-4">
            <div className="space-y-4">
              <Input 
                value={embedCode.shortcode} 
                readOnly 
                className="font-mono text-sm"
              />
              <div className="flex items-center justify-between">
                <p className="text-sm text-muted-foreground">
                  Use this shortcode in WordPress with the WPStream plugin installed.
                </p>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => copyToClipboard(embedCode.shortcode, 'shortcode')}
                >
                  {copied === 'shortcode' ? (
                    <>
                      <Check className="mr-2 h-4 w-4" />
                      Copied
                    </>
                  ) : (
                    <>
                      <Copy className="mr-2 h-4 w-4" />
                      Copy
                    </>
                  )}
                </Button>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="widget" className="mt-4">
            <div className="space-y-4">
              <Textarea 
                value={embedCode.widget} 
                readOnly 
                className="h-32 font-mono text-sm"
              />
              <div className="flex items-center justify-between">
                <p className="text-sm text-muted-foreground">
                  Embed as a JavaScript widget that can be customized with data attributes.
                </p>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => copyToClipboard(embedCode.widget, 'widget')}
                >
                  {copied === 'widget' ? (
                    <>
                      <Check className="mr-2 h-4 w-4" />
                      Copied
                    </>
                  ) : (
                    <>
                      <Copy className="mr-2 h-4 w-4" />
                      Copy
                    </>
                  )}
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="bg-muted/50 px-6 py-3">
        <p className="text-xs text-muted-foreground">
          Embed code can be used on any website that allows iframe or script embedding.
        </p>
      </CardFooter>
    </Card>
  );
}