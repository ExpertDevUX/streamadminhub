#!/bin/bash
echo "Stream Manager EC2 instance launched" > /var/log/user-data.log
