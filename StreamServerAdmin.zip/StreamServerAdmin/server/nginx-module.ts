import { exec } from "child_process";
import { promises as fs } from "fs";
import * as path from "path";
import { promisify } from "util";

const execAsync = promisify(exec);

// Path to NGINX configuration files
const NGINX_CONFIG_PATH = "/etc/nginx";
const NGINX_RTMP_CONFIG_PATH = "/etc/nginx/modules-enabled/rtmp.conf";
const NGINX_DEFAULT_CONFIG_PATH = "/etc/nginx/sites-available/default";
const NGINX_LOG_PATH = "/var/log/nginx";

/**
 * Check if NGINX is installed
 */
async function isNginxInstalled(): Promise<boolean> {
  try {
    await execAsync("nginx -v");
    return true;
  } catch (error) {
    return false;
  }
}

/**
 * Check if NGINX is running
 */
async function isNginxRunning(): Promise<boolean> {
  try {
    await execAsync("systemctl is-active --quiet nginx");
    return true;
  } catch (error) {
    return false;
  }
}

/**
 * Check if RTMP module is installed
 */
async function isRtmpModuleInstalled(): Promise<boolean> {
  try {
    // Check if the RTMP module configuration exists
    await fs.access(NGINX_RTMP_CONFIG_PATH);
    
    // Also check if libnginx-mod-rtmp is installed
    const { stdout } = await execAsync("dpkg -l | grep libnginx-mod-rtmp");
    return stdout.includes("libnginx-mod-rtmp");
  } catch (error) {
    return false;
  }
}

/**
 * Install NGINX with RTMP module
 */
async function installNginx(): Promise<{ success: boolean, message: string }> {
  try {
    // Check if NGINX is already installed
    if (await isNginxInstalled()) {
      // If it's installed but RTMP module is missing, just install the module
      if (!(await isRtmpModuleInstalled())) {
        await execAsync("apt-get update && apt-get install -y libnginx-mod-rtmp");
        await createRtmpConfig();
        await restartNginx();
        return { 
          success: true, 
          message: "RTMP module installed successfully and NGINX restarted" 
        };
      }
      return { 
        success: true, 
        message: "NGINX with RTMP module is already installed" 
      };
    }
    
    // Install NGINX and RTMP module
    await execAsync("apt-get update && apt-get install -y nginx libnginx-mod-rtmp");
    
    // Create RTMP configuration
    await createRtmpConfig();
    
    // Update default site configuration to serve HLS
    await updateDefaultSiteConfig();
    
    // Create HLS directory
    await execAsync("mkdir -p /var/www/html/hls");
    await execAsync("chown -R www-data:www-data /var/www/html/hls");
    
    // Start NGINX service
    await execAsync("systemctl enable nginx");
    await execAsync("systemctl start nginx");
    
    return { 
      success: true, 
      message: "NGINX with RTMP module installed successfully" 
    };
  } catch (error) {
    console.error("Error installing NGINX:", error);
    return { 
      success: false, 
      message: `Failed to install NGINX: ${error instanceof Error ? error.message : String(error)}` 
    };
  }
}

/**
 * Repair NGINX installation and configuration
 */
async function repairNginx(): Promise<{ success: boolean, message: string }> {
  try {
    // Check if NGINX is installed
    if (!(await isNginxInstalled())) {
      return { 
        success: false, 
        message: "NGINX is not installed. Please install it first." 
      };
    }
    
    // Fix common issues
    await fixCommonNginxIssues();
    
    // Check NGINX configuration
    const configValid = await checkNginxConfig();
    
    if (!configValid) {
      return { 
        success: false, 
        message: "NGINX configuration is still invalid after repair attempts" 
      };
    }
    
    // Restart NGINX service
    await restartNginx();
    
    return { 
      success: true, 
      message: "NGINX repaired and restarted successfully" 
    };
  } catch (error) {
    console.error("Error repairing NGINX:", error);
    return { 
      success: false, 
      message: `Failed to repair NGINX: ${error instanceof Error ? error.message : String(error)}` 
    };
  }
}

/**
 * Check if NGINX configuration is valid
 */
async function checkNginxConfig(): Promise<boolean> {
  try {
    await execAsync("nginx -t");
    return true;
  } catch (error) {
    return false;
  }
}

/**
 * Fix common NGINX issues
 */
async function fixCommonNginxIssues(): Promise<void> {
  // 1. Fix permissions
  await execAsync("mkdir -p /var/log/nginx");
  await execAsync("chown -R www-data:www-data /var/log/nginx");
  await execAsync("mkdir -p /var/www/html/hls");
  await execAsync("chown -R www-data:www-data /var/www/html/hls");
  
  // 2. Fix missing RTMP module
  if (!(await isRtmpModuleInstalled())) {
    await execAsync("apt-get update && apt-get install -y libnginx-mod-rtmp");
    await createRtmpConfig();
  }
  
  // 3. Recreate config files if missing
  if (!(await fileExists(NGINX_RTMP_CONFIG_PATH))) {
    await createRtmpConfig();
  }
  
  // 4. Fix default site config if needed
  await updateDefaultSiteConfig();
  
  // 5. Clear any stale pid files
  try {
    await execAsync("rm -f /var/run/nginx.pid");
  } catch (error) {
    // Ignore error if the pid file doesn't exist
  }
}

/**
 * Uninstall NGINX and cleanup configuration
 */
async function uninstallNginx(): Promise<{ success: boolean, message: string }> {
  try {
    // Check if NGINX is installed
    if (!(await isNginxInstalled())) {
      return { 
        success: true, 
        message: "NGINX is not installed" 
      };
    }
    
    // Stop NGINX service
    await execAsync("systemctl stop nginx");
    await execAsync("systemctl disable nginx");
    
    // Uninstall NGINX and RTMP module
    await execAsync("apt-get remove -y nginx libnginx-mod-rtmp");
    await execAsync("apt-get autoremove -y");
    
    // Remove configuration files
    await execAsync("rm -rf /etc/nginx");
    await execAsync("rm -rf /var/log/nginx");
    await execAsync("rm -rf /var/www/html/hls");
    
    return { 
      success: true, 
      message: "NGINX uninstalled successfully" 
    };
  } catch (error) {
    console.error("Error uninstalling NGINX:", error);
    return { 
      success: false, 
      message: `Failed to uninstall NGINX: ${error instanceof Error ? error.message : String(error)}` 
    };
  }
}

/**
 * Get NGINX status
 */
async function getNginxStatus(): Promise<{
  installed: boolean;
  running: boolean;
  rtmpModuleInstalled: boolean;
  configValid: boolean;
}> {
  const installed = await isNginxInstalled();
  const running = installed ? await isNginxRunning() : false;
  const rtmpModuleInstalled = installed ? await isRtmpModuleInstalled() : false;
  const configValid = installed ? await checkNginxConfig() : false;
  
  return {
    installed,
    running,
    rtmpModuleInstalled,
    configValid
  };
}

/**
 * Create RTMP configuration file
 */
/**
 * Change the NGINX RTMP port
 */
async function changeRtmpPort(port: number): Promise<{ success: boolean, message: string }> {
  try {
    // Validate port
    if (port < 1024 || port > 65535) {
      return { 
        success: false, 
        message: "Port must be between 1024 and 65535" 
      };
    }

    // Check if NGINX is installed
    if (!await isNginxInstalled()) {
      return { 
        success: false, 
        message: "NGINX is not installed. Please install NGINX first." 
      };
    }

    // Update RTMP config with new port
    await createRtmpConfig(port);
    
    // Restart NGINX to apply changes
    await restartNginx();
    
    return { 
      success: true, 
      message: `RTMP port successfully changed to ${port}` 
    };
  } catch (error) {
    console.error("Error changing RTMP port:", error);
    return { 
      success: false, 
      message: `Failed to change RTMP port: ${error instanceof Error ? error.message : String(error)}` 
    };
  }
}

/**
 * Change the NGINX HTTP port
 */
async function changeHttpPort(port: number): Promise<{ success: boolean, message: string }> {
  try {
    // Validate port
    if (port < 1024 || port > 65535) {
      return { 
        success: false, 
        message: "Port must be between 1024 and 65535" 
      };
    }

    // Check if NGINX is installed
    if (!await isNginxInstalled()) {
      return { 
        success: false, 
        message: "NGINX is not installed. Please install NGINX first." 
      };
    }
    
    // Update default site config with new port
    await updateDefaultSiteConfig(port);
    
    // Restart NGINX to apply changes
    await restartNginx();
    
    return { 
      success: true, 
      message: `HTTP port successfully changed to ${port}` 
    };
  } catch (error) {
    console.error("Error changing HTTP port:", error);
    return { 
      success: false, 
      message: `Failed to change HTTP port: ${error instanceof Error ? error.message : String(error)}` 
    };
  }
}

async function createRtmpConfig(port: number = 1935): Promise<void> {
  const rtmpConfig = `
# RTMP configuration for video streaming
rtmp {
    server {
        listen ${port}; # RTMP port
        chunk_size 4096;
        
        # Define application for live streaming
        application live {
            live on;
            record off;
            
            # HLS output
            hls on;
            hls_path /var/www/html/hls;
            hls_fragment 3;
            hls_playlist_length 60;
            
            # Enable HLS for all streams
            hls_variant _low bandwidth=800000 resolution=640x360;
            hls_variant _mid bandwidth=1200000 resolution=842x480;
            hls_variant _high bandwidth=2400000 resolution=1280x720;
            hls_variant _hd bandwidth=4800000 resolution=1920x1080;
            
            # Only allow streaming from the local system and authenticated users
            allow publish 127.0.0.1;
            deny publish all;
            
            # Only allow playing from anywhere
            allow play all;
        }
    }
}
`;

  // Ensure directory exists
  await execAsync("mkdir -p /etc/nginx/modules-enabled");
  
  // Create backup of existing configuration if it exists
  if (await fileExists(NGINX_RTMP_CONFIG_PATH)) {
    await backupConfigFile(NGINX_RTMP_CONFIG_PATH);
  }
  
  // Write the configuration file
  await fs.writeFile(NGINX_RTMP_CONFIG_PATH, rtmpConfig);
}

/**
 * Update default site configuration to serve HLS content
 */
async function updateDefaultSiteConfig(port: number = 80): Promise<void> {
  // Check if default config exists
  const defaultConfigExists = await fileExists(NGINX_DEFAULT_CONFIG_PATH);
  
  if (!defaultConfigExists) {
    // Create a basic default config
    const defaultConfig = `
server {
    listen ${port} default_server;
    listen [::]:${port} default_server;
    
    root /var/www/html;
    
    index index.html index.htm index.nginx-debian.html;
    
    server_name _;
    
    location / {
        try_files $uri $uri/ =404;
    }
    
    # HLS streaming location
    location /hls {
        types {
            application/vnd.apple.mpegurl m3u8;
            video/mp2t ts;
        }
        
        root /var/www/html;
        add_header Cache-Control no-cache;
        add_header Access-Control-Allow-Origin *;
    }
}
`;
    await fs.writeFile(NGINX_DEFAULT_CONFIG_PATH, defaultConfig);
  } else {
    // Read existing config
    let config = await fs.readFile(NGINX_DEFAULT_CONFIG_PATH, 'utf8');

    // Create backup of the existing configuration before modifying
    await backupConfigFile(NGINX_DEFAULT_CONFIG_PATH);
    
    // Update the port if specified
    if (port !== 80) {
      // Replace both IPv4 and IPv6 listen directives
      config = config.replace(
        /listen\s+\d+\s+default_server;/g,
        `listen ${port} default_server;`
      );
      config = config.replace(
        /listen\s+\[::\]:\d+\s+default_server;/g,
        `listen [::]:${port} default_server;`
      );
    }
    
    // Check if HLS section already exists
    if (!config.includes('location /hls')) {
      // Add HLS section to existing config
      const hlsSection = `
    # HLS streaming location
    location /hls {
        types {
            application/vnd.apple.mpegurl m3u8;
            video/mp2t ts;
        }
        
        root /var/www/html;
        add_header Cache-Control no-cache;
        add_header Access-Control-Allow-Origin *;
    }
`;
      
      // Insert before the closing bracket of the server block
      const updatedConfig = config.replace(
        /}(\s*)$/,
        `${hlsSection}}$1`
      );
      
      await fs.writeFile(NGINX_DEFAULT_CONFIG_PATH, updatedConfig);
    } else {
      // If we only need to update the port
      await fs.writeFile(NGINX_DEFAULT_CONFIG_PATH, config);
    }
  }
  
  // Create symbolic link if it doesn't exist
  const enabledPath = "/etc/nginx/sites-enabled/default";
  if (!(await fileExists(enabledPath))) {
    await execAsync(`ln -s ${NGINX_DEFAULT_CONFIG_PATH} ${enabledPath}`);
  }
}

/**
 * Restart NGINX service
 */
async function restartNginx(): Promise<void> {
  await execAsync("systemctl restart nginx");
}

/**
 * Backup a configuration file before modifying it
 */
async function backupConfigFile(filePath: string): Promise<string | null> {
  try {
    // Check if file exists
    if (!await fileExists(filePath)) {
      return null;
    }
    
    // Create backup directory if it doesn't exist
    const backupDir = "/etc/nginx/backups";
    await fs.mkdir(backupDir, { recursive: true });
    
    // Create backup with timestamp
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const fileName = path.basename(filePath);
    const backupPath = `${backupDir}/${fileName}.${timestamp}.bak`;
    
    // Copy file to backup
    await fs.copyFile(filePath, backupPath);
    console.log(`Created backup of ${filePath} at ${backupPath}`);
    
    return backupPath;
  } catch (error) {
    console.error(`Error creating backup for ${filePath}:`, error);
    return null;
  }
}

/**
 * Check if a file exists
 */
async function fileExists(filePath: string): Promise<boolean> {
  try {
    await fs.access(filePath);
    return true;
  } catch (error) {
    return false;
  }
}

/**
 * Execute a shell command and return the output
 */
async function execCommand(command: string): Promise<string> {
  try {
    const { stdout } = await execAsync(command);
    return stdout.trim();
  } catch (error) {
    if (error instanceof Error && 'stderr' in error) {
      // @ts-ignore
      return error.stderr.trim();
    }
    throw error;
  }
}

// Export functions
export {
  getNginxStatus,
  installNginx,
  repairNginx,
  uninstallNginx,
  changeRtmpPort,
  changeHttpPort
};