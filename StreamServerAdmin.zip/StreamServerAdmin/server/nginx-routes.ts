import { Express, Request, Response } from "express";
import { storage } from "./storage";
import { 
    getNginxStatus, 
    installNginx, 
    repairNginx, 
    uninstallNginx,
    changeRtmpPort,
    changeHttpPort
} from "./nginx-module";

export function setupNginxRoutes(app: Express) {
    // Get NGINX status
    app.get("/api/nginx/status", async (req: Request, res: Response) => {
        if (!req.isAuthenticated() || !req.user.isAdmin) {
            return res.status(403).json({ message: "Admin permissions required" });
        }
        
        try {
            const status = await getNginxStatus();
            res.json(status);
        } catch (error) {
            console.error("Error getting NGINX status:", error);
            res.status(500).json({ 
                message: "Error getting NGINX status", 
                error: error instanceof Error ? error.message : String(error) 
            });
        }
    });
    
    // Install NGINX
    app.post("/api/nginx/install", async (req: Request, res: Response) => {
        if (!req.isAuthenticated() || !req.user.isAdmin) {
            return res.status(403).json({ message: "Admin permissions required" });
        }
        
        try {
            const result = await installNginx();
            
            // Log activity
            await storage.createActivity({
                type: "nginx_installation",
                message: `NGINX installation ${result.success ? "succeeded" : "failed"}: ${result.message}`,
                userId: req.user.id,
                relatedType: "server"
            });
            
            res.json(result);
        } catch (error) {
            console.error("Error installing NGINX:", error);
            res.status(500).json({ 
                message: "Error installing NGINX", 
                error: error instanceof Error ? error.message : String(error) 
            });
        }
    });
    
    // Repair NGINX
    app.post("/api/nginx/repair", async (req: Request, res: Response) => {
        if (!req.isAuthenticated() || !req.user.isAdmin) {
            return res.status(403).json({ message: "Admin permissions required" });
        }
        
        try {
            const result = await repairNginx();
            
            // Log activity
            await storage.createActivity({
                type: "nginx_repair",
                message: `NGINX repair ${result.success ? "succeeded" : "failed"}: ${result.message}`,
                userId: req.user.id,
                relatedType: "server"
            });
            
            res.json(result);
        } catch (error) {
            console.error("Error repairing NGINX:", error);
            res.status(500).json({ 
                message: "Error repairing NGINX", 
                error: error instanceof Error ? error.message : String(error) 
            });
        }
    });
    
    // Uninstall NGINX
    app.post("/api/nginx/uninstall", async (req: Request, res: Response) => {
        if (!req.isAuthenticated() || !req.user.isAdmin) {
            return res.status(403).json({ message: "Admin permissions required" });
        }
        
        try {
            const result = await uninstallNginx();
            
            // Log activity
            await storage.createActivity({
                type: "nginx_uninstallation",
                message: `NGINX uninstallation ${result.success ? "succeeded" : "failed"}: ${result.message}`,
                userId: req.user.id,
                relatedType: "server"
            });
            
            res.json(result);
        } catch (error) {
            console.error("Error uninstalling NGINX:", error);
            res.status(500).json({ 
                message: "Error uninstalling NGINX", 
                error: error instanceof Error ? error.message : String(error) 
            });
        }
    });
    
    // Change RTMP port
    app.post("/api/nginx/change-rtmp-port", async (req: Request, res: Response) => {
        if (!req.isAuthenticated() || !req.user.isAdmin) {
            return res.status(403).json({ message: "Admin permissions required" });
        }
        
        const { port } = req.body;
        
        if (!port || isNaN(Number(port))) {
            return res.status(400).json({ message: "Invalid port number" });
        }
        
        try {
            const result = await changeRtmpPort(Number(port));
            
            // Log activity
            await storage.createActivity({
                type: "nginx_port_change",
                message: `RTMP port change to ${port} ${result.success ? "succeeded" : "failed"}: ${result.message}`,
                userId: req.user.id,
                relatedType: "server"
            });
            
            res.json(result);
        } catch (error) {
            console.error("Error changing RTMP port:", error);
            res.status(500).json({ 
                message: "Error changing RTMP port", 
                error: error instanceof Error ? error.message : String(error) 
            });
        }
    });
    
    // Change HTTP port
    app.post("/api/nginx/change-http-port", async (req: Request, res: Response) => {
        if (!req.isAuthenticated() || !req.user.isAdmin) {
            return res.status(403).json({ message: "Admin permissions required" });
        }
        
        const { port } = req.body;
        
        if (!port || isNaN(Number(port))) {
            return res.status(400).json({ message: "Invalid port number" });
        }
        
        try {
            const result = await changeHttpPort(Number(port));
            
            // Log activity
            await storage.createActivity({
                type: "nginx_port_change",
                message: `HTTP port change to ${port} ${result.success ? "succeeded" : "failed"}: ${result.message}`,
                userId: req.user.id,
                relatedType: "server"
            });
            
            res.json(result);
        } catch (error) {
            console.error("Error changing HTTP port:", error);
            res.status(500).json({ 
                message: "Error changing HTTP port", 
                error: error instanceof Error ? error.message : String(error) 
            });
        }
    });
}