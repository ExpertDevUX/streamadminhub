import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { setupRTMPRoutes } from "./rtmp";
import { setupIntegrationRoutes } from "./integration-routes";
import { setupStorageRoutes } from "./storage-routes";
import { 
  InsertStream, insertStreamSchema,
  SiteConfig, insertSiteConfigSchema 
} from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import { WebSocketServer, WebSocket } from "ws";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);
  
  // Setup RTMP server management routes
  setupRTMPRoutes(app);
  
  // Setup integration routes
  setupIntegrationRoutes(app);
  
  // Setup storage management routes
  setupStorageRoutes(app);

  // Stream management routes
  app.get("/api/streams", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Authentication required");
    }
    
    let streams;
    if (req.user.isAdmin) {
      streams = await storage.getAllStreams();
    } else {
      streams = await storage.getUserStreams(req.user.id);
    }
    
    res.json(streams);
  });
  
  app.get("/api/streams/active", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Authentication required");
    }
    
    const streams = await storage.getActiveStreams();
    res.json(streams);
  });
  
  // Public endpoint to get stream by key (used for embed player)
  app.get("/api/streams/key/:streamKey", async (req, res) => {
    const streamKey = req.params.streamKey;
    const stream = await storage.getStreamByKey(streamKey);
    
    if (!stream) {
      return res.status(404).json({ error: "Stream not found" });
    }
    
    // Return only necessary information for public embedding
    const publicStream = {
      id: stream.id,
      name: stream.name,
      streamKey: stream.streamKey,
      isActive: stream.isActive,
      viewers: stream.viewers,
      startedAt: stream.startedAt
    };
    
    // Track viewer count only for active streams
    if (stream.isActive) {
      // Increment view count
      const viewers = (stream.viewers || 0) + 1;
      await storage.updateStream(stream.id, { viewers });
      
      // Log activity
      await storage.createActivity({
        type: "stream_viewed",
        message: `Stream "${stream.name}" was viewed`,
        relatedId: stream.id,
        relatedType: "stream"
      });
    }
    
    res.json(publicStream);
  });
  
  app.get("/api/streams/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Authentication required");
    }
    
    const streamId = parseInt(req.params.id);
    const stream = await storage.getStream(streamId);
    
    if (!stream) {
      return res.status(404).send("Stream not found");
    }
    
    // Check if user has access to this stream
    if (!req.user.isAdmin && stream.userId !== req.user.id) {
      return res.status(403).send("Access denied");
    }
    
    res.json(stream);
  });
  
  app.post("/api/streams", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Authentication required");
    }
    
    try {
      const streamData = insertStreamSchema.parse({
        ...req.body,
        userId: req.user.id
      });
      
      const stream = await storage.createStream(streamData);
      
      // Log activity
      await storage.createActivity({
        type: "stream_created",
        message: `Stream "${stream.name}" was created`,
        userId: req.user.id,
        relatedId: stream.id,
        relatedType: "stream"
      });
      
      res.status(201).json(stream);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).send("Error creating stream");
    }
  });
  
  app.put("/api/streams/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Authentication required");
    }
    
    const streamId = parseInt(req.params.id);
    const stream = await storage.getStream(streamId);
    
    if (!stream) {
      return res.status(404).send("Stream not found");
    }
    
    // Check if user has access to update this stream
    if (!req.user.isAdmin && stream.userId !== req.user.id) {
      return res.status(403).send("Access denied");
    }
    
    const updatedStream = await storage.updateStream(streamId, req.body);
    
    // Log activity for stream start/stop
    if (req.body.isActive !== undefined && req.body.isActive !== stream.isActive) {
      await storage.createActivity({
        type: req.body.isActive ? "stream_started" : "stream_stopped",
        message: `Stream "${stream.name}" was ${req.body.isActive ? "started" : "stopped"}`,
        userId: req.user.id,
        relatedId: stream.id,
        relatedType: "stream"
      });
    }
    
    res.json(updatedStream);
  });
  
  app.delete("/api/streams/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Authentication required");
    }
    
    const streamId = parseInt(req.params.id);
    const stream = await storage.getStream(streamId);
    
    if (!stream) {
      return res.status(404).send("Stream not found");
    }
    
    // Check if user has access to delete this stream
    if (!req.user.isAdmin && stream.userId !== req.user.id) {
      return res.status(403).send("Access denied");
    }
    
    await storage.deleteStream(streamId);
    
    // Log activity
    await storage.createActivity({
      type: "stream_deleted",
      message: `Stream "${stream.name}" was deleted`,
      userId: req.user.id,
      relatedId: streamId,
      relatedType: "stream"
    });
    
    res.status(204).send();
  });
  
  // Generate a new stream key
  app.post("/api/streams/generate-key", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Authentication required");
    }
    
    // Generate a random stream key (16 characters alphanumeric)
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let streamKey = '';
    for (let i = 0; i < 16; i++) {
      streamKey += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    
    res.json({ streamKey });
  });
  
  // Demo stream (for testing embed functionality)
  app.get("/api/demo-stream", async (req, res) => {
    // Check if demo stream exists
    let demoStream = await storage.getStreamByKey("DEMO12345");
    
    // If not, create one
    if (!demoStream) {
      demoStream = await storage.createStream({
        name: "Demo Stream",
        streamKey: "DEMO12345",
        userId: 1, // Admin user
        isActive: true,
        quality: "720p"
      });
      
      // Log activity
      await storage.createActivity({
        type: "stream_created",
        message: "Demo stream created",
        relatedId: demoStream.id,
        relatedType: "stream"
      });
    }
    
    res.json({
      id: demoStream.id,
      name: demoStream.name,
      streamKey: demoStream.streamKey,
      embedUrl: `/embed/${demoStream.streamKey}`,
      iframeCode: `<iframe src="${req.protocol}://${req.get('host')}/embed/${demoStream.streamKey}" width="640" height="360" frameborder="0" allowfullscreen></iframe>`
    });
  });
  
  // User management routes (admin only)
  app.get("/api/admin/users", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).send("Admin permissions required");
    }
    
    const users = await storage.getAllUsers();
    res.json(users);
  });
  
  app.post("/api/admin/users", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).send("Admin permissions required");
    }
    
    try {
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(req.body.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const user = await storage.createUser(req.body);
      
      // Log activity
      await storage.createActivity({
        type: "user_created",
        message: `User "${user.username}" was created`,
        userId: req.user.id,
        relatedId: user.id,
        relatedType: "user"
      });
      
      res.status(201).json(user);
    } catch (error) {
      console.error("Error creating user:", error);
      res.status(500).json({ message: "Error creating user" });
    }
  });
  
  app.patch("/api/admin/users/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).send("Admin permissions required");
    }
    
    const userId = parseInt(req.params.id);
    const user = await storage.getUser(userId);
    
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    try {
      // If username is being changed, check if it's unique
      if (req.body.username && req.body.username !== user.username) {
        const existingUser = await storage.getUserByUsername(req.body.username);
        if (existingUser) {
          return res.status(400).json({ message: "Username already exists" });
        }
      }
      
      const updatedUser = await storage.updateUser(userId, req.body);
      
      // Log activity
      await storage.createActivity({
        type: "user_updated",
        message: `User "${user.username}" was updated`,
        userId: req.user.id,
        relatedId: user.id,
        relatedType: "user"
      });
      
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating user:", error);
      res.status(500).json({ message: "Error updating user" });
    }
  });
  
  app.delete("/api/admin/users/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).send("Admin permissions required");
    }
    
    const userId = parseInt(req.params.id);
    
    // Don't allow deleting the current user
    if (userId === req.user.id) {
      return res.status(400).json({ message: "Cannot delete your own account" });
    }
    
    const user = await storage.getUser(userId);
    
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    try {
      await storage.deleteUser(userId);
      
      // Log activity
      await storage.createActivity({
        type: "user_deleted",
        message: `User "${user.username}" was deleted`,
        userId: req.user.id,
        relatedId: userId,
        relatedType: "user"
      });
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting user:", error);
      res.status(500).json({ message: "Error deleting user" });
    }
  });
  
  // Server management routes
  app.get("/api/servers", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Authentication required");
    }
    
    const servers = await storage.getAllServers();
    res.json(servers);
  });
  
  app.get("/api/servers/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Authentication required");
    }
    
    const serverId = parseInt(req.params.id);
    const server = await storage.getServer(serverId);
    
    if (!server) {
      return res.status(404).send("Server not found");
    }
    
    res.json(server);
  });
  
  app.post("/api/admin/servers", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).send("Admin permissions required");
    }
    
    const server = await storage.createServer(req.body);
    
    // Log activity
    await storage.createActivity({
      type: "server_created",
      message: `Server "${server.name}" was created`,
      userId: req.user.id,
      relatedId: server.id,
      relatedType: "server"
    });
    
    res.status(201).json(server);
  });
  
  app.put("/api/admin/servers/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).send("Admin permissions required");
    }
    
    const serverId = parseInt(req.params.id);
    const server = await storage.getServer(serverId);
    
    if (!server) {
      return res.status(404).send("Server not found");
    }
    
    const updatedServer = await storage.updateServer(serverId, req.body);
    
    // Log activity
    await storage.createActivity({
      type: "server_updated",
      message: `Server "${server.name}" configuration was updated`,
      userId: req.user.id,
      relatedId: server.id,
      relatedType: "server"
    });
    
    res.json(updatedServer);
  });
  
  app.delete("/api/admin/servers/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).send("Admin permissions required");
    }
    
    const serverId = parseInt(req.params.id);
    const server = await storage.getServer(serverId);
    
    if (!server) {
      return res.status(404).send("Server not found");
    }
    
    await storage.deleteServer(serverId);
    
    // Log activity
    await storage.createActivity({
      type: "server_deleted",
      message: `Server "${server.name}" was deleted`,
      userId: req.user.id,
      relatedId: serverId,
      relatedType: "server"
    });
    
    res.status(204).send();
  });
  
  // Site Configuration routes (admin only)
  app.get("/api/site-config", async (req, res) => {
    // Allow public access to site configuration for client display
    const config = await storage.getSiteConfig();
    
    // Return limited public data if not authenticated
    if (!req.isAuthenticated()) {
      const publicConfig = config ? {
        siteName: config.siteName,
        primaryColor: config.primaryColor,
        faviconUrl: config.faviconUrl,
        siteDescription: config.siteDescription,
        hostname: config.hostname,
        domain: config.domain,
      } : null;
      
      return res.json(publicConfig);
    }
    
    // Return full configuration data for authenticated users
    res.json(config);
  });
  
  app.put("/api/admin/site-config", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).send("Admin permissions required");
    }
    
    try {
      const updatedConfig = await storage.updateSiteConfig(req.body);
      
      // Log activity
      await storage.createActivity({
        type: "config_updated",
        message: "Site configuration was updated",
        userId: req.user.id,
        relatedType: "config"
      });
      
      res.json(updatedConfig);
    } catch (error) {
      console.error("Error updating site configuration:", error);
      res.status(500).json({ message: "Error updating site configuration" });
    }
  });
  
  // Activity routes
  app.get("/api/activities", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Authentication required");
    }
    
    const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
    const activities = await storage.getAllActivities(limit);
    res.json(activities);
  });

  const httpServer = createServer(app);
  
  // Set up WebSocket server for real-time metrics updates
  const wss = new WebSocketServer({ 
    server: httpServer, 
    path: '/ws' 
  });
  
  const clients = new Set<WebSocket>();
  
  wss.on('connection', (ws) => {
    clients.add(ws);
    
    console.log('WebSocket client connected, total connections:', clients.size);
    
    // Send initial server status data
    const initialData = {
      type: 'serverStatus',
      data: {
        cpu: 0,
        memory: 0,
        disk: 0,
        network: 0,
        uptime: 0
      }
    };
    
    ws.send(JSON.stringify(initialData));
    
    ws.on('message', (message) => {
      // Handle incoming messages from clients if needed
      console.log('Received message from client:', message.toString());
    });
    
    ws.on('close', () => {
      clients.delete(ws);
      console.log('WebSocket client disconnected, remaining connections:', clients.size);
    });
  });
  
  // Function to broadcast updates to all connected clients
  const broadcastMetrics = (data: any) => {
    const message = JSON.stringify({
      type: 'serverMetrics',
      data
    });
    
    // Convert Set to Array for iteration to avoid downlevelIteration flag requirement
    Array.from(clients).forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  };
  
  // Simulate sending periodic updates (in a real app, this would be triggered by actual metrics changes)
  setInterval(() => {
    if (clients.size > 0) {
      const metrics = {
        timestamp: Date.now(),
        cpu: Math.floor(Math.random() * 100),
        memory: Math.floor(Math.random() * 100),
        disk: Math.floor(Math.random() * 100),
        network: Math.floor(Math.random() * 100)
      };
      
      broadcastMetrics(metrics);
    }
  }, 5000); // Update every 5 seconds
  
  return httpServer;
}
