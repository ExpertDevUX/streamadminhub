#!/bin/bash

# Simple EC2 Deployment Script
# Run this script on your EC2 instance (18.143.175.52)

# Create deployment directory
mkdir -p ~/stream-manager
cd ~/stream-manager

# Download deployment files using presigned URLs
echo "Downloading deployment files..."
wget "https://stream-manager-deployment-1743048279.s3.amazonaws.com/stream-manager-deploy.tar.gz?AWSAccessKeyId=AKIATU4A3TWPEKJQKXVU&Signature=5gt%2F5YcL0nxGdrz3NJhM1EXJlTo%3D&Expires=1743052487" -O stream-manager-deploy.tar.gz
wget "https://stream-manager-deployment-1743048279.s3.amazonaws.com/aws-install.sh?AWSAccessKeyId=AKIATU4A3TWPEKJQKXVU&Signature=XNhT1FKa7uiDIzjLK61IQbomkgs%3D&Expires=1743052493" -O aws-install.sh

# Extract and run installation
echo "Extracting and installing..."
tar -xzf stream-manager-deploy.tar.gz
chmod +x aws-install.sh
sudo ./aws-install.sh

# Cleanup
echo "Cleaning up temporary files..."
cd ~
rm -rf ~/stream-manager

echo "Deployment completed successfully!"
echo "Stream Manager should now be available at: http://18.143.175.52"
echo "Default admin credentials:"
echo "Username: admin"
echo "Password: Check /etc/stream-manager/credentials.conf on your server"