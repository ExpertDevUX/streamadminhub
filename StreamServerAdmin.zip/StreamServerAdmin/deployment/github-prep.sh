#!/bin/bash

# Video Stream Server Manager - GitHub Preparation Script
# This script helps to prepare your project for GitHub deployment

# Colors for output formatting
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Function to print messages
print_message() {
  echo -e "${GREEN}[+] $1${NC}"
}

print_warning() {
  echo -e "${YELLOW}[!] $1${NC}"
}

print_error() {
  echo -e "${RED}[-] $1${NC}"
}

print_message "Preparing your Video Stream Server Manager for GitHub deployment"

# Check if git is installed
if ! command -v git &> /dev/null; then
    print_error "Git is not installed. Please install git first."
    exit 1
fi

# Check if the directory is already a git repository
if [ -d .git ]; then
    print_warning "This directory is already a git repository"
else
    print_message "Initializing git repository"
    git init
fi

# Remove any existing origin
git remote remove origin 2>/dev/null

print_message "Please enter your GitHub repository URL (e.g., https://github.com/username/repo.git):"
read github_url

if [ -z "$github_url" ]; then
    print_error "GitHub URL cannot be empty"
    exit 1
fi

# Add the new origin
git remote add origin "$github_url"
print_message "Added remote origin: $github_url"

# Clean up sensitive data and build artifacts
print_warning "Cleaning up sensitive data and build artifacts"
rm -rf node_modules
rm -rf dist
rm -rf .env*
rm -rf logs/*.log

# Make sure installation scripts are executable
chmod +x install.sh
chmod +x aws-install.sh

# Check for any large files
print_message "Checking for large files (>10MB) that might cause problems with GitHub:"
find . -type f -size +10M -not -path "./node_modules/*" -not -path "./dist/*" | while read file; do
    print_warning "Large file detected: $file"
    echo "Consider adding this to .gitignore if it's not essential for the repository"
done

print_message "GitHub preparation completed"
print_message "Next steps:"
print_message "1. Review your files and make any final changes"
print_message "2. Run the following commands to push to GitHub:"
echo ""
echo "   git add ."
echo "   git commit -m \"Initial commit\""
echo "   git branch -M main"
echo "   git push -u origin main"
echo ""
print_warning "Remember to set up GitHub secrets for any sensitive information"
print_message "For more information, check the documentation in README.md"