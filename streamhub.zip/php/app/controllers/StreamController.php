<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Models\Stream;
use App\Models\Activity;

/**
 * Stream Controller
 * Handles stream management
 */
class StreamController extends Controller
{
    private $streamModel;
    private $activityModel;
    
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->streamModel = new Stream();
        $this->activityModel = new Activity();
    }
    
    /**
     * List all streams
     */
    public function index(Request $request, Response $response)
    {
        // Require login
        $this->requireLogin();
        
        // Get user streams
        $streams = $this->streamModel->getByUserId($this->getUserId());
        
        return $response->render('streams/index', [
            'title' => 'My Streams - ' . APP_NAME,
            'streams' => $streams
        ]);
    }
    
    /**
     * Show stream details
     */
    public function show(Request $request, Response $response, $params)
    {
        // Require login
        $this->requireLogin();
        
        // Get stream ID from params
        $streamId = $params['id'] ?? null;
        
        if (!$streamId) {
            $this->setFlash('error', 'Stream not found');
            return $response->redirect('/streams');
        }
        
        // Get stream details
        $stream = $this->streamModel->find($streamId);
        
        // Check if stream exists and belongs to the user
        if (!$stream || $stream['user_id'] != $this->getUserId()) {
            $this->setFlash('error', 'Stream not found');
            return $response->redirect('/streams');
        }
        
        // Get stream activities
        $activities = $this->activityModel->getByEntityId('stream', $streamId, 20);
        
        // Generate RTMP URL
        $rtmpUrl = 'rtmp://' . RTMP_HOST . ':' . RTMP_PORT . '/live/' . $stream['stream_key'];
        
        return $response->render('streams/show', [
            'title' => $stream['title'] . ' - ' . APP_NAME,
            'stream' => $stream,
            'activities' => $activities,
            'rtmpUrl' => $rtmpUrl,
            'embedCode' => $this->generateEmbedCode($stream)
        ]);
    }
    
    /**
     * Show create stream form
     */
    public function create(Request $request, Response $response)
    {
        // Require login
        $this->requireLogin();
        
        return $response->render('streams/create', [
            'title' => 'Create Stream - ' . APP_NAME
        ]);
    }
    
    /**
     * Process create stream form
     */
    public function store(Request $request, Response $response)
    {
        // Require login
        $this->requireLogin();
        
        // Get form data
        $data = $request->getBody();
        
        // Validate form data
        $errors = $this->validateStreamData($data);
        
        // If there are errors, show the form again
        if (!empty($errors)) {
            $this->setFlash('errors', $errors);
            $this->setFlash('old', $data);
            return $response->redirect('/streams/create');
        }
        
        // Add user ID
        $data['user_id'] = $this->getUserId();
        
        // Create stream
        $stream = $this->streamModel->createStream($data);
        
        // Log activity
        $this->activityModel->log($this->getUserId(), 'stream_created', 'stream', $stream['id']);
        
        // Stream created successfully
        $this->setFlash('success', 'Stream created successfully');
        return $response->redirect('/streams/' . $stream['id']);
    }
    
    /**
     * Show edit stream form
     */
    public function edit(Request $request, Response $response, $params)
    {
        // Require login
        $this->requireLogin();
        
        // Get stream ID from params
        $streamId = $params['id'] ?? null;
        
        if (!$streamId) {
            $this->setFlash('error', 'Stream not found');
            return $response->redirect('/streams');
        }
        
        // Get stream details
        $stream = $this->streamModel->find($streamId);
        
        // Check if stream exists and belongs to the user
        if (!$stream || $stream['user_id'] != $this->getUserId()) {
            $this->setFlash('error', 'Stream not found');
            return $response->redirect('/streams');
        }
        
        return $response->render('streams/edit', [
            'title' => 'Edit Stream - ' . APP_NAME,
            'stream' => $stream
        ]);
    }
    
    /**
     * Process edit stream form
     */
    public function update(Request $request, Response $response, $params)
    {
        // Require login
        $this->requireLogin();
        
        // Get stream ID from params
        $streamId = $params['id'] ?? null;
        
        if (!$streamId) {
            $this->setFlash('error', 'Stream not found');
            return $response->redirect('/streams');
        }
        
        // Get stream details
        $stream = $this->streamModel->find($streamId);
        
        // Check if stream exists and belongs to the user
        if (!$stream || $stream['user_id'] != $this->getUserId()) {
            $this->setFlash('error', 'Stream not found');
            return $response->redirect('/streams');
        }
        
        // Get form data
        $data = $request->getBody();
        
        // Validate form data
        $errors = $this->validateStreamData($data);
        
        // If there are errors, show the form again
        if (!empty($errors)) {
            $this->setFlash('errors', $errors);
            $this->setFlash('old', $data);
            return $response->redirect('/streams/' . $streamId . '/edit');
        }
        
        // Update stream
        $updatedStream = $this->streamModel->update($streamId, $data);
        
        // Log activity
        $this->activityModel->log($this->getUserId(), 'stream_updated', 'stream', $streamId);
        
        // Stream updated successfully
        $this->setFlash('success', 'Stream updated successfully');
        return $response->redirect('/streams/' . $streamId);
    }
    
    /**
     * Process stream deletion
     */
    public function delete(Request $request, Response $response, $params)
    {
        // Require login
        $this->requireLogin();
        
        // Get stream ID from params
        $streamId = $params['id'] ?? null;
        
        if (!$streamId) {
            $this->setFlash('error', 'Stream not found');
            return $response->redirect('/streams');
        }
        
        // Get stream details
        $stream = $this->streamModel->find($streamId);
        
        // Check if stream exists and belongs to the user
        if (!$stream || $stream['user_id'] != $this->getUserId()) {
            $this->setFlash('error', 'Stream not found');
            return $response->redirect('/streams');
        }
        
        // Check if stream is live
        if ($stream['status'] === 'live') {
            $this->setFlash('error', 'Cannot delete a live stream');
            return $response->redirect('/streams/' . $streamId);
        }
        
        // Delete stream
        $this->streamModel->delete($streamId);
        
        // Log activity
        $this->activityModel->log($this->getUserId(), 'stream_deleted', 'stream', $streamId);
        
        // Stream deleted successfully
        $this->setFlash('success', 'Stream deleted successfully');
        return $response->redirect('/streams');
    }
    
    /**
     * Generate embed code for a stream
     */
    private function generateEmbedCode($stream)
    {
        $embedUrl = APP_URL . '/embed/' . $stream['id'];
        
        return '<iframe src="' . $embedUrl . '" width="640" height="360" frameborder="0" allowfullscreen></iframe>';
    }
    
    /**
     * Validate stream data
     */
    private function validateStreamData($data)
    {
        $errors = [];
        
        // Title
        if (empty($data['title'])) {
            $errors['title'] = 'Title is required';
        } elseif (strlen($data['title']) < 3) {
            $errors['title'] = 'Title must be at least 3 characters';
        } elseif (strlen($data['title']) > 100) {
            $errors['title'] = 'Title cannot be more than 100 characters';
        }
        
        return $errors;
    }
}