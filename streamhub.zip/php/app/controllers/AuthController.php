<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Models\User;

/**
 * Authentication Controller
 * Handles user authentication (login, logout, register)
 */
class AuthController extends Controller
{
    private $userModel;
    
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->userModel = new User();
    }
    
    /**
     * Show login page
     */
    public function showLogin(Request $request, Response $response)
    {
        // Redirect to dashboard if already logged in
        if ($this->isLoggedIn()) {
            return $response->redirect('/dashboard');
        }
        
        return $response->render('auth/login', [
            'title' => 'Login - ' . APP_NAME
        ]);
    }
    
    /**
     * Process login form
     */
    public function login(Request $request, Response $response)
    {
        // Get form data
        $data = $request->getBody();
        $username = $data['username'] ?? '';
        $password = $data['password'] ?? '';
        
        // Validate form data
        $errors = [];
        
        if (empty($username)) {
            $errors['username'] = 'Username is required';
        }
        
        if (empty($password)) {
            $errors['password'] = 'Password is required';
        }
        
        // If there are errors, show the login form again
        if (!empty($errors)) {
            $this->setFlash('errors', $errors);
            $this->setFlash('old', ['username' => $username]);
            return $response->redirect('/login');
        }
        
        // Attempt to log in
        $user = $this->userModel->login($username, $password);
        
        if (!$user) {
            $this->setFlash('error', 'Invalid username or password');
            $this->setFlash('old', ['username' => $username]);
            return $response->redirect('/login');
        }
        
        // Log in successful
        $this->setFlash('success', 'You have been logged in');
        return $response->redirect('/dashboard');
    }
    
    /**
     * Log out
     */
    public function logout(Request $request, Response $response)
    {
        $this->userModel->logout();
        $this->setFlash('success', 'You have been logged out');
        return $response->redirect('/login');
    }
    
    /**
     * Show registration page
     */
    public function showRegister(Request $request, Response $response)
    {
        // Redirect to dashboard if already logged in
        if ($this->isLoggedIn()) {
            return $response->redirect('/dashboard');
        }
        
        return $response->render('auth/register', [
            'title' => 'Register - ' . APP_NAME
        ]);
    }
    
    /**
     * Process registration form
     */
    public function register(Request $request, Response $response)
    {
        // Get form data
        $data = $request->getBody();
        
        // Validate form data
        $errors = $this->validateRegistrationData($data);
        
        // If there are errors, show the registration form again
        if (!empty($errors)) {
            $this->setFlash('errors', $errors);
            $this->setFlash('old', $data);
            return $response->redirect('/register');
        }
        
        // Check if username is already taken
        $existingUser = $this->userModel->findByUsername($data['username']);
        
        if ($existingUser) {
            $this->setFlash('error', 'Username is already taken');
            $this->setFlash('old', $data);
            return $response->redirect('/register');
        }
        
        // Check if email is already taken
        if (!empty($data['email'])) {
            $existingEmail = $this->userModel->findByEmail($data['email']);
            
            if ($existingEmail) {
                $this->setFlash('error', 'Email is already taken');
                $this->setFlash('old', $data);
                return $response->redirect('/register');
            }
        }
        
        // Register the user
        $user = $this->userModel->register($data);
        
        // Log in the user
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['is_admin'] = (bool)$user['is_admin'];
        
        // Registration successful
        $this->setFlash('success', 'You have been registered and logged in');
        return $response->redirect('/dashboard');
    }
    
    /**
     * Validate registration data
     */
    private function validateRegistrationData($data)
    {
        $errors = [];
        
        // Username
        if (empty($data['username'])) {
            $errors['username'] = 'Username is required';
        } elseif (strlen($data['username']) < 3) {
            $errors['username'] = 'Username must be at least 3 characters';
        } elseif (strlen($data['username']) > 50) {
            $errors['username'] = 'Username cannot be more than 50 characters';
        } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $data['username'])) {
            $errors['username'] = 'Username can only contain letters, numbers, and underscores';
        }
        
        // Password
        if (empty($data['password'])) {
            $errors['password'] = 'Password is required';
        } elseif (strlen($data['password']) < 6) {
            $errors['password'] = 'Password must be at least 6 characters';
        }
        
        // Confirm Password
        if (empty($data['confirm_password'])) {
            $errors['confirm_password'] = 'Please confirm your password';
        } elseif ($data['password'] !== $data['confirm_password']) {
            $errors['confirm_password'] = 'Passwords do not match';
        }
        
        // Email (optional)
        if (!empty($data['email']) && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'Invalid email format';
        }
        
        return $errors;
    }
}