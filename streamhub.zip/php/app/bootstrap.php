<?php
/**
 * Stream Manager - Bootstrap file
 * 
 * This file initializes the application by:
 * - Setting up error handling and logging
 * - Registering autoload function
 * - Loading configuration
 * - Setting up database connection
 */

// Prevent direct access
if (!defined('ROOT_PATH')) {
    die('Direct access to this file is not allowed');
}

// Set error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Register autoloader
spl_autoload_register(function ($className) {
    // Convert namespace to path
    $className = str_replace('\\', DIRECTORY_SEPARATOR, $className);
    
    // Remove App\ namespace prefix
    if (strpos($className, 'App' . DIRECTORY_SEPARATOR) === 0) {
        $className = substr($className, 4);
    }
    
    $filePath = ROOT_PATH . DIRECTORY_SEPARATOR . $className . '.php';
    
    if (file_exists($filePath)) {
        require_once $filePath;
        return true;
    }
    
    return false;
});

// Create necessary directories if they don't exist
$directories = [
    ROOT_PATH . '/storage',
    ROOT_PATH . '/storage/logs',
    ROOT_PATH . '/config',
    ROOT_PATH . '/public/uploads'
];

foreach ($directories as $dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
}

// Load configuration
$configFile = ROOT_PATH . '/config/config.php';
if (!file_exists($configFile)) {
    die('Configuration file not found. Please run setup.php first.');
}

// Initialize session
session_start();

// Set default timezone
date_default_timezone_set('UTC');