<?php
namespace App\Models;

use App\Core\Model;

/**
 * Server Model
 */
class Server extends Model
{
    protected $table = 'servers';
    protected $fillable = [
        'name', 'host', 'port', 'status', 'server_type', 'region',
        'provider', 'is_default', 'config', 'capacity', 'current_load'
    ];
    
    /**
     * Get all active servers
     */
    public function getActiveServers()
    {
        return $this->where('status', 'online');
    }
    
    /**
     * Get the default server
     */
    public function getDefaultServer()
    {
        return $this->firstWhere('is_default', true);
    }
    
    /**
     * Update server status
     */
    public function updateStatus($serverId, $status)
    {
        $sql = "UPDATE {$this->table} 
                SET status = :status, updated_at = :updated_at
                WHERE id = :id
                RETURNING *";
        
        return $this->db->find($sql, [
            'id' => $serverId,
            'status' => $status,
            'updated_at' => date('Y-m-d H:i:s')
        ]);
    }
    
    /**
     * Update server load
     */
    public function updateLoad($serverId, $load)
    {
        $sql = "UPDATE {$this->table} 
                SET current_load = :load, updated_at = :updated_at
                WHERE id = :id
                RETURNING *";
        
        return $this->db->find($sql, [
            'id' => $serverId,
            'load' => $load,
            'updated_at' => date('Y-m-d H:i:s')
        ]);
    }
    
    /**
     * Create a server with JSON config
     */
    public function createServer($data)
    {
        // Convert config to JSON if it's an array
        if (isset($data['config']) && is_array($data['config'])) {
            $data['config'] = json_encode($data['config']);
        }
        
        // Set default values
        $data['status'] = $data['status'] ?? 'offline';
        $data['server_type'] = $data['server_type'] ?? 'rtmp';
        $data['is_default'] = $data['is_default'] ?? false;
        $data['capacity'] = $data['capacity'] ?? 100;
        $data['current_load'] = $data['current_load'] ?? 0;
        
        return $this->create($data);
    }
    
    /**
     * Find a server in a specific region with available capacity
     */
    public function findAvailableInRegion($region, $minCapacity = 10)
    {
        $sql = "SELECT * FROM {$this->table} 
                WHERE region = :region 
                AND status = 'online' 
                AND (capacity - current_load) >= :min_capacity
                ORDER BY current_load ASC
                LIMIT 1";
        
        return $this->db->find($sql, [
            'region' => $region,
            'min_capacity' => $minCapacity
        ]);
    }
    
    /**
     * Get server with all related streams
     */
    public function getWithStreams($serverId)
    {
        $server = $this->find($serverId);
        
        if (!$server) {
            return null;
        }
        
        // Get streams associated with this server
        $sql = "SELECT s.* FROM streams s
                JOIN bandwidth_allocations ba ON s.id = ba.stream_id
                WHERE ba.server_id = :server_id AND s.status = 'live'";
        
        $streams = $this->db->findAll($sql, ['server_id' => $serverId]);
        
        $server['streams'] = $streams;
        
        return $server;
    }
}