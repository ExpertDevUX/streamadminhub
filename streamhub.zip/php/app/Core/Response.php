<?php
namespace App\Core;

/**
 * Response class
 * Handles HTTP responses
 */
class Response
{
    /**
     * Set HTTP status code
     */
    public function setStatusCode($code)
    {
        http_response_code($code);
        return $this;
    }
    
    /**
     * Redirect to another URL
     */
    public function redirect($url)
    {
        header("Location: $url");
        exit;
    }
    
    /**
     * Return JSON response
     */
    public function json($data, $statusCode = 200)
    {
        $this->setStatusCode($statusCode);
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }
    
    /**
     * Render a view
     */
    public function render($view, $params = [])
    {
        // Get the application instance
        $app = Application::getInstance();
        
        // Extract flash messages
        $params['flash'] = $app->session->getFlash();
        
        // Add auth data
        $params['isLoggedIn'] = isset($_SESSION['user_id']);
        $params['userId'] = $_SESSION['user_id'] ?? null;
        $params['username'] = $_SESSION['username'] ?? null;
        $params['isAdmin'] = $_SESSION['is_admin'] ?? false;
        
        // Convert view path to file path
        $viewPath = str_replace('/', DIRECTORY_SEPARATOR, $view);
        $viewFile = APP_ROOT . "/views/{$viewPath}.php";
        
        // Check if view file exists
        if (!file_exists($viewFile)) {
            throw new \Exception("View file not found: {$viewFile}");
        }
        
        // Start output buffering
        ob_start();
        
        // Extract params to variables
        extract($params);
        
        // Include view file
        include $viewFile;
        
        // Get the contents of the buffer
        $content = ob_get_clean();
        
        // Check for layout
        $layoutFile = APP_ROOT . "/views/layouts/main.php";
        
        if (file_exists($layoutFile)) {
            // Include layout
            ob_start();
            extract($params);
            $content = $this->applyLayout($layoutFile, $content, $params);
            return ob_get_clean();
        }
        
        return $content;
    }
    
    /**
     * Apply layout to content
     */
    private function applyLayout($layoutFile, $content, $params)
    {
        // Extract params
        extract($params);
        
        // Define the content variable for layout
        $viewContent = $content;
        
        // Include layout file
        include $layoutFile;
        
        return ob_get_contents();
    }
}