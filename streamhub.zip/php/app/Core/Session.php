<?php
namespace App\Core;

/**
 * Session class
 * Handles session management
 */
class Session
{
    protected $flashMessages = [];
    
    /**
     * Constructor
     */
    public function __construct()
    {
        // Start session if not already started
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        // Load flash messages from session
        $this->flashMessages = $_SESSION['flash_messages'] ?? [];
        
        // Clear flash messages from session
        $_SESSION['flash_messages'] = [];
    }
    
    /**
     * Set a session value
     */
    public function set($key, $value)
    {
        $_SESSION[$key] = $value;
    }
    
    /**
     * Get a session value
     */
    public function get($key, $default = null)
    {
        return $_SESSION[$key] ?? $default;
    }
    
    /**
     * Remove a session value
     */
    public function remove($key)
    {
        unset($_SESSION[$key]);
    }
    
    /**
     * Set a flash message
     */
    public function setFlash($key, $message)
    {
        $this->flashMessages[$key] = $message;
        $_SESSION['flash_messages'][$key] = $message;
    }
    
    /**
     * Get a flash message
     */
    public function getFlash($key = null)
    {
        if ($key === null) {
            return $this->flashMessages;
        }
        
        return $this->flashMessages[$key] ?? null;
    }
    
    /**
     * Check if a flash message exists
     */
    public function hasFlash($key)
    {
        return isset($this->flashMessages[$key]);
    }
    
    /**
     * Clear all session data
     */
    public function clear()
    {
        $_SESSION = [];
    }
    
    /**
     * Destroy the session
     */
    public function destroy()
    {
        $this->clear();
        
        // If it's desired to kill the session, also delete the session cookie.
        // Note: This will destroy the session, and not just the session data!
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params["path"],
                $params["domain"],
                $params["secure"],
                $params["httponly"]
            );
        }
        
        session_destroy();
    }
    
    /**
     * Regenerate session ID
     */
    public function regenerateId()
    {
        session_regenerate_id(true);
    }
}