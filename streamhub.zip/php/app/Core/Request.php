<?php
namespace App\Core;

/**
 * Request class
 * Handles HTTP request data
 */
class Request
{
    /**
     * Get request path
     */
    public function getPath()
    {
        $path = $_SERVER['REQUEST_URI'] ?? '/';
        $position = strpos($path, '?');
        
        if ($position === false) {
            return $path;
        }
        
        return substr($path, 0, $position);
    }
    
    /**
     * Get request method
     */
    public function getMethod()
    {
        return strtolower($_SERVER['REQUEST_METHOD']);
    }
    
    /**
     * Get request body
     */
    public function getBody()
    {
        $body = [];
        
        if ($this->getMethod() === 'get') {
            foreach ($_GET as $key => $value) {
                $body[$key] = filter_input(INPUT_GET, $key, FILTER_SANITIZE_SPECIAL_CHARS);
            }
        }
        
        if ($this->getMethod() === 'post') {
            // Check for JSON input
            $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
            
            if (strpos($contentType, 'application/json') !== false) {
                $json = file_get_contents('php://input');
                $data = json_decode($json, true);
                
                if ($data) {
                    return $data;
                }
            }
            
            // Check for form input
            foreach ($_POST as $key => $value) {
                $body[$key] = filter_input(INPUT_POST, $key, FILTER_SANITIZE_SPECIAL_CHARS);
            }
        }
        
        return $body;
    }
    
    /**
     * Check if request has a specific parameter
     */
    public function has($key)
    {
        $body = $this->getBody();
        return isset($body[$key]);
    }
    
    /**
     * Get a specific parameter from the request
     */
    public function get($key, $default = null)
    {
        $body = $this->getBody();
        return $body[$key] ?? $default;
    }
    
    /**
     * Get all query parameters
     */
    public function getQueryParams()
    {
        $queryParams = [];
        
        foreach ($_GET as $key => $value) {
            $queryParams[$key] = filter_input(INPUT_GET, $key, FILTER_SANITIZE_SPECIAL_CHARS);
        }
        
        return $queryParams;
    }
    
    /**
     * Get a specific query parameter
     */
    public function getQueryParam($key, $default = null)
    {
        $queryParams = $this->getQueryParams();
        return $queryParams[$key] ?? $default;
    }
    
    /**
     * Check if request is AJAX
     */
    public function isAjax()
    {
        return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
               strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }
}