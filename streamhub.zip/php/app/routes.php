<?php
/**
 * Application Routes
 */

use App\Core\Router;
use App\Core\Request;
use App\Core\Response;
use App\Controllers\AuthController;
use App\Controllers\DashboardController;
use App\Controllers\StreamController;
use App\Controllers\ServerController;
use App\Controllers\AdminController;

// Create Router instance
$request = new Request();
$response = new Response();
$router = new Router($request, $response);

// Home Route
$router->get('/', function(Request $request, Response $response) {
    return $response->render('home/index', [
        'title' => APP_NAME . ' - Video Stream Server Management'
    ]);
});

// Auth Routes
$router->get('/login', [new AuthController(), 'showLogin']);
$router->post('/login', [new AuthController(), 'login']);
$router->get('/register', [new AuthController(), 'showRegister']);
$router->post('/register', [new AuthController(), 'register']);
$router->get('/logout', [new AuthController(), 'logout']);

// Dashboard Routes
$router->get('/dashboard', [new DashboardController(), 'index']);
$router->get('/dashboard/metrics', [new DashboardController(), 'metrics']);

// Stream Routes
$router->get('/streams', [new StreamController(), 'index']);
$router->get('/streams/create', [new StreamController(), 'create']);
$router->post('/streams', [new StreamController(), 'store']);
$router->get('/streams/:id', [new StreamController(), 'show']);
$router->get('/streams/:id/edit', [new StreamController(), 'edit']);
$router->post('/streams/:id', [new StreamController(), 'update']);
$router->post('/streams/:id/delete', [new StreamController(), 'delete']);

// API Routes
$router->get('/api/status', function(Request $request, Response $response) {
    return $response->json([
        'status' => 'ok',
        'version' => '1.0.0',
        'time' => date('Y-m-d H:i:s')
    ]);
});

// Error Routes
$router->get('/error/404', function(Request $request, Response $response) {
    $response->setStatusCode(404);
    return $response->render('errors/404', [
        'title' => 'Page Not Found - ' . APP_NAME
    ]);
});

$router->get('/error/500', function(Request $request, Response $response) {
    $response->setStatusCode(500);
    return $response->render('errors/500', [
        'title' => 'Server Error - ' . APP_NAME
    ]);
});