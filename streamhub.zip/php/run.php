<?php
/**
 * Development server for PHP demo
 * This script will start a PHP development server for testing
 */

$host = 'localhost';
$port = 8080;
$root = __DIR__;

echo "Starting PHP development server at http://{$host}:{$port}\n";
echo "Press Ctrl+C to stop the server\n\n";

// Check if the server is already running
$check = shell_exec("ps aux | grep 'php -S {$host}:{$port}' | grep -v grep");
if ($check) {
    echo "Server is already running.\n";
    exit(1);
}

// Start PHP development server
passthru("php -S {$host}:{$port} -t {$root}");