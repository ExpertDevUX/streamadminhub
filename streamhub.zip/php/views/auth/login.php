<div class="container py-5">
    <div class="row">
        <div class="col-md-6 mb-4 mb-md-0">
            <h2 class="mb-4">Login to Stream Manager</h2>
            
            <!-- Display any validation errors -->
            <?php if (isset($flash['errors']) && !empty($flash['errors'])): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php foreach ($flash['errors'] as $field => $error): ?>
                            <li><?= $error ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="/login">
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control" id="username" name="username" 
                           value="<?= isset($flash['old']['username']) ? htmlspecialchars($flash['old']['username']) : '' ?>" required>
                </div>
                
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                
                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="remember" name="remember">
                    <label class="form-check-label" for="remember">Remember me</label>
                </div>
                
                <button type="submit" class="btn btn-primary">Login</button>
            </form>
            
            <div class="mt-3">
                <p>Don't have an account? <a href="/register">Register here</a></p>
            </div>
        </div>
        
        <div class="col-md-6 d-flex align-items-center">
            <div class="bg-light rounded p-4 w-100">
                <h3 class="mb-3">Stream Manager Platform</h3>
                <p class="mb-3">Access your streaming dashboard to:</p>
                <ul>
                    <li>Manage your RTMP servers</li>
                    <li>Monitor streaming metrics in real-time</li>
                    <li>Configure SSL certificates</li>
                    <li>Embed streams on your websites</li>
                    <li>Integrate with WordPress and other platforms</li>
                </ul>
                <p>Need help? <a href="/contact">Contact support</a></p>
            </div>
        </div>
    </div>
</div>