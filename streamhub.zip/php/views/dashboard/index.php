<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Dashboard</h2>
        <a href="/streams/create" class="btn btn-primary">
            <i class="bi bi-plus-circle"></i> Create Stream
        </a>
    </div>
    
    <!-- Stats Overview -->
    <div class="row g-4 mb-4">
        <div class="col-md-3">
            <div class="card border-0 bg-primary text-white h-100">
                <div class="card-body">
                    <h5 class="card-title">Total Streams</h5>
                    <h2 class="display-4 fw-bold"><?= $stats['total_streams'] ?></h2>
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="card border-0 bg-success text-white h-100">
                <div class="card-body">
                    <h5 class="card-title">Active Streams</h5>
                    <h2 class="display-4 fw-bold"><?= $stats['active_streams'] ?></h2>
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="card border-0 bg-info text-white h-100">
                <div class="card-body">
                    <h5 class="card-title">Viewers</h5>
                    <h2 class="display-4 fw-bold"><?= $stats['total_viewers'] ?></h2>
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="card border-0 bg-secondary text-white h-100">
                <div class="card-body">
                    <h5 class="card-title">Active Servers</h5>
                    <h2 class="display-4 fw-bold"><?= $stats['active_servers'] ?>/<?= $stats['total_servers'] ?></h2>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Recent Streams -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-header bg-white border-bottom-0">
            <h5 class="mb-0">Recent Streams</h5>
        </div>
        <div class="card-body">
            <?php if (empty($streams)): ?>
                <div class="text-center py-4">
                    <i class="bi bi-broadcast display-1 text-muted"></i>
                    <p class="mt-3">You don't have any streams yet.</p>
                    <a href="/streams/create" class="btn btn-primary">Create Your First Stream</a>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Status</th>
                                <th>Stream Key</th>
                                <th>Viewers</th>
                                <th>Created</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach (array_slice($streams, 0, 5) as $stream): ?>
                                <tr>
                                    <td>
                                        <a href="/streams/<?= $stream['id'] ?>" class="text-decoration-none">
                                            <?= htmlspecialchars($stream['title']) ?>
                                        </a>
                                    </td>
                                    <td>
                                        <?php if ($stream['status'] === 'live'): ?>
                                            <span class="badge bg-success">Live</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Offline</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="input-group input-group-sm">
                                            <input type="text" class="form-control form-control-sm" 
                                                   value="<?= htmlspecialchars($stream['stream_key']) ?>" readonly>
                                            <button class="btn btn-outline-secondary btn-sm copy-btn" 
                                                    data-clipboard-text="<?= htmlspecialchars($stream['stream_key']) ?>" type="button">
                                                <i class="bi bi-clipboard"></i>
                                            </button>
                                        </div>
                                    </td>
                                    <td>
                                        <?= $stream['status'] === 'live' ? $stream['viewer_count'] : '-' ?>
                                    </td>
                                    <td>
                                        <?= date('M j, Y', strtotime($stream['created_at'])) ?>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <a href="/streams/<?= $stream['id'] ?>" class="btn btn-outline-primary">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                            <a href="/streams/<?= $stream['id'] ?>/edit" class="btn btn-outline-secondary">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <?php if (count($streams) > 5): ?>
                    <div class="text-center mt-3">
                        <a href="/streams" class="btn btn-outline-primary">View All Streams</a>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Server Status -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-header bg-white border-bottom-0">
            <h5 class="mb-0">Server Status</h5>
        </div>
        <div class="card-body">
            <?php if (empty($servers)): ?>
                <div class="text-center py-4">
                    <i class="bi bi-hdd-rack display-1 text-muted"></i>
                    <p class="mt-3">No servers configured.</p>
                </div>
            <?php else: ?>
                <div class="row g-4">
                    <?php foreach ($servers as $server): ?>
                        <div class="col-md-6 col-lg-4">
                            <div class="card h-100 <?= $server['status'] === 'online' ? 'border-success' : 'border-danger' ?>">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-center mb-3">
                                        <h5 class="card-title mb-0"><?= htmlspecialchars($server['name']) ?></h5>
                                        <?php if ($server['status'] === 'online'): ?>
                                            <span class="badge bg-success">Online</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Offline</span>
                                        <?php endif; ?>
                                    </div>
                                    <p class="card-text">
                                        <strong>Host:</strong> <?= htmlspecialchars($server['host']) ?><br>
                                        <strong>Port:</strong> <?= $server['port'] ?><br>
                                        <strong>Type:</strong> <?= strtoupper($server['server_type']) ?>
                                    </p>
                                    
                                    <?php if ($server['status'] === 'online'): ?>
                                        <div class="mb-3">
                                            <label class="form-label mb-1">Server Load</label>
                                            <div class="progress">
                                                <?php 
                                                    $loadPercent = $server['current_load'] / $server['capacity'] * 100;
                                                    $loadClass = $loadPercent < 60 ? 'bg-success' : ($loadPercent < 80 ? 'bg-warning' : 'bg-danger');
                                                ?>
                                                <div class="progress-bar <?= $loadClass ?>" style="width: <?= $loadPercent ?>%">
                                                    <?= round($loadPercent) ?>%
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <div class="d-flex justify-content-end">
                                        <a href="/admin/servers/<?= $server['id'] ?>" class="btn btn-sm btn-outline-primary">
                                            <i class="bi bi-gear"></i> Manage
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Recent Activities -->
    <div class="card border-0 shadow-sm">
        <div class="card-header bg-white border-bottom-0">
            <h5 class="mb-0">Recent Activities</h5>
        </div>
        <div class="card-body">
            <?php if (empty($activities)): ?>
                <div class="text-center py-4">
                    <i class="bi bi-activity display-1 text-muted"></i>
                    <p class="mt-3">No recent activities.</p>
                </div>
            <?php else: ?>
                <ul class="list-group list-group-flush">
                    <?php foreach ($activities as $activity): ?>
                        <li class="list-group-item px-0">
                            <div class="d-flex align-items-center">
                                <div class="me-3">
                                    <?php 
                                        $icon = 'bi-info-circle';
                                        switch ($activity['type']) {
                                            case 'stream_created':
                                                $icon = 'bi-plus-circle text-success';
                                                break;
                                            case 'stream_updated':
                                                $icon = 'bi-pencil text-primary';
                                                break;
                                            case 'stream_deleted':
                                                $icon = 'bi-trash text-danger';
                                                break;
                                            case 'stream_started':
                                                $icon = 'bi-play-circle text-success';
                                                break;
                                            case 'stream_ended':
                                                $icon = 'bi-stop-circle text-warning';
                                                break;
                                            case 'viewer_count_updated':
                                                $icon = 'bi-people text-info';
                                                break;
                                            case 'server_status_changed':
                                                $icon = 'bi-hdd-rack text-primary';
                                                break;
                                            case 'nginx_installation':
                                                $icon = 'bi-server text-primary';
                                                break;
                                            case 'ssl_certificate':
                                                $icon = 'bi-shield-check text-success';
                                                break;
                                        }
                                    ?>
                                    <i class="bi <?= $icon ?> fs-4"></i>
                                </div>
                                <div>
                                    <p class="mb-0"><?= htmlspecialchars($activity['message']) ?></p>
                                    <small class="text-muted"><?= date('M j, Y g:i A', strtotime($activity['created_at'])) ?></small>
                                </div>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Enable clipboard functionality for stream keys
    const copyButtons = document.querySelectorAll('.copy-btn');
    copyButtons.forEach(button => {
        button.addEventListener('click', function() {
            const text = this.getAttribute('data-clipboard-text');
            navigator.clipboard.writeText(text).then(() => {
                const originalHTML = this.innerHTML;
                this.innerHTML = '<i class="bi bi-check"></i>';
                setTimeout(() => {
                    this.innerHTML = originalHTML;
                }, 2000);
            });
        });
    });
});
</script>