<?php
/**
 * Setup script for Stream Manager PHP Version
 * 
 * This script initializes the database and creates a default admin user
 */

// Define root path
define('ROOT_PATH', __DIR__);

// Create necessary directories
$directories = [
    ROOT_PATH . '/storage',
    ROOT_PATH . '/storage/logs',
    ROOT_PATH . '/config',
    ROOT_PATH . '/public/uploads'
];

foreach ($directories as $dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
        echo "Created directory: $dir\n";
    }
}

// Create config file if it doesn't exist
$configFile = ROOT_PATH . '/config/config.php';
if (!file_exists($configFile)) {
    $configContent = <<<'CONFIG'
<?php
// Application configuration

return [
    // Application settings
    'app' => [
        'name' => 'Stream Manager',
        'url' => 'http://localhost:8080',
        'debug' => true,
        'timezone' => 'UTC',
        'secret_key' => ''.bin2hex(random_bytes(32)).''
    ],
    
    // Database settings (SQLite by default)
    'database' => [
        'type' => 'sqlite',
        'path' => dirname(__DIR__) . '/storage/database.sqlite'
    ],
    
    // Session settings
    'session' => [
        'name' => 'stream_manager_session',
        'lifetime' => 7200,
        'path' => '/',
        'secure' => false
    ],
    
    // Paths
    'paths' => [
        'views' => dirname(__DIR__) . '/views',
        'logs' => dirname(__DIR__) . '/storage/logs',
        'uploads' => dirname(__DIR__) . '/public/uploads'
    ],
    
    // Stream settings
    'streams' => [
        'rtmp_server' => 'rtmp://localhost:1935/live',
        'hls_server' => 'http://localhost:8080/hls',
        'thumbnail_path' => '/public/thumbnails',
        'default_thumbnail' => '/public/images/default-thumbnail.jpg'
    ]
];
CONFIG;
    
    file_put_contents($configFile, $configContent);
    echo "Created config file: $configFile\n";
}

// Create database schema
$dbPath = ROOT_PATH . '/storage/database.sqlite';
$createDb = !file_exists($dbPath);

if ($createDb) {
    // Create SQLite database
    $db = new PDO("sqlite:$dbPath");
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Users table
    $db->exec("CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        email TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        full_name TEXT,
        role TEXT DEFAULT 'user',
        avatar TEXT,
        preferences TEXT,
        api_key TEXT,
        is_active INTEGER DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    
    // Streams table
    $db->exec("CREATE TABLE streams (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        description TEXT,
        stream_key TEXT NOT NULL UNIQUE,
        is_active INTEGER DEFAULT 0,
        is_private INTEGER DEFAULT 0,
        viewers INTEGER DEFAULT 0,
        max_viewers INTEGER DEFAULT 0,
        started_at DATETIME,
        ended_at DATETIME,
        duration INTEGER DEFAULT 0,
        thumbnail TEXT,
        settings TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    )");
    
    // Servers table
    $db->exec("CREATE TABLE servers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        host TEXT NOT NULL,
        port INTEGER NOT NULL,
        username TEXT,
        password TEXT,
        type TEXT NOT NULL,
        status TEXT DEFAULT 'offline',
        settings TEXT,
        metrics TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    
    // Activities table
    $db->exec("CREATE TABLE activities (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        type TEXT NOT NULL,
        entity_type TEXT,
        entity_id INTEGER,
        message TEXT,
        details TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL
    )");
    
    // Integrations table
    $db->exec("CREATE TABLE integrations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        type TEXT NOT NULL,
        config TEXT,
        enabled INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    
    // Site configuration table
    $db->exec("CREATE TABLE site_config (
        id INTEGER PRIMARY KEY,
        site_name TEXT NOT NULL DEFAULT 'Stream Manager',
        site_url TEXT NOT NULL DEFAULT 'http://localhost:8080',
        logo TEXT,
        favicon TEXT,
        theme TEXT DEFAULT 'light',
        language TEXT DEFAULT 'en',
        registration_enabled INTEGER DEFAULT 1,
        maintenance_mode INTEGER DEFAULT 0,
        settings TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    
    echo "Created database schema\n";
    
    // Create default admin user (username: admin, password: admin123)
    $username = 'admin';
    $email = 'admin@example.com';
    $password = password_hash('admin123', PASSWORD_DEFAULT);
    
    $db->exec("INSERT INTO users (username, email, password, role) 
               VALUES ('$username', '$email', '$password', 'admin')");
    
    // Insert default server
    $db->exec("INSERT INTO servers (name, host, port, type, status, settings) 
               VALUES ('Default RTMP Server', 'localhost', 1935, 'rtmp', 'online', 
               '{\"hls_enabled\":true,\"recording_enabled\":false}')");
    
    // Insert demo stream
    $streamKey = bin2hex(random_bytes(8));
    $db->exec("INSERT INTO streams (user_id, name, description, stream_key) 
               VALUES (1, 'Demo Stream', 'This is a demo stream for testing', '$streamKey')");
    
    // Insert default site config
    $db->exec("INSERT INTO site_config (id, site_name, site_url) VALUES (1, 'Stream Manager', 'http://localhost:8080')");
    
    // Log activity for user creation
    $db->exec("INSERT INTO activities (user_id, type, entity_type, entity_id, message) 
               VALUES (1, 'user_created', 'user', 1, 'Default admin user was created')");
    
    echo "Created default admin user (username: admin, password: admin123)\n";
    echo "Created default server and demo stream\n";
    
    // Close database connection
    $db = null;
} else {
    echo "Database already exists, skipping schema creation\n";
}

echo "\nSetup completed successfully!\n";
echo "You can now run the application with: php run.php\n";
echo "Access the application at: http://localhost:8080\n";
echo "Login with username: admin and password: admin123\n";
?>