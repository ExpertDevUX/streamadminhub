#!/bin/bash
#
# RTMP Server Installation Script for Stream Manager
# This script installs and configures NGINX with RTMP module
#

# Set colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Default values
HTTP_PORT=80
RTMP_PORT=1935
HLS_PATH="/var/www/html/hls"
LOW_RESOURCE=false

# Parse command line arguments
while [[ $# -gt 0 ]]; do
  case $1 in
    --http-port)
      HTTP_PORT="$2"
      shift 2
      ;;
    --rtmp-port)
      RTMP_PORT="$2"
      shift 2
      ;;
    --hls-path)
      HLS_PATH="$2"
      shift 2
      ;;
    --low-resource)
      LOW_RESOURCE=true
      shift
      ;;
    --help)
      echo "Usage: $0 [OPTIONS]"
      echo "Options:"
      echo "  --http-port PORT    HTTP port for NGINX (default: 80)"
      echo "  --rtmp-port PORT    RTMP port for NGINX (default: 1935)"
      echo "  --hls-path PATH     Path for HLS segments (default: /var/www/html/hls)"
      echo "  --low-resource      Configure for low resource environments"
      echo "  --help              Show this help message"
      exit 0
      ;;
    *)
      echo "Unknown option: $1"
      echo "Use --help for usage information"
      exit 1
      ;;
  esac
done

# Check if script is running as root
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}Error:${NC} This script must be run as root"
  echo "Please run with: sudo $0 $*"
  exit 1
fi

# Function to check if a command exists
command_exists() {
  command -v "$1" >/dev/null 2>&1
}

# Detect OS and package manager
detect_os() {
  if command_exists apt-get; then
    PKG_MANAGER="apt-get"
    INSTALL_CMD="apt-get install -y"
    UPDATE_CMD="apt-get update"
  elif command_exists yum; then
    PKG_MANAGER="yum"
    INSTALL_CMD="yum install -y"
    UPDATE_CMD="yum check-update"
  elif command_exists dnf; then
    PKG_MANAGER="dnf"
    INSTALL_CMD="dnf install -y"
    UPDATE_CMD="dnf check-update"
  else
    echo -e "${RED}Error:${NC} Unsupported operating system"
    echo "This script supports Ubuntu, Debian, CentOS, and Fedora"
    exit 1
  fi
}

# Install required packages
install_dependencies() {
  echo -e "${GREEN}Installing dependencies...${NC}"
  $UPDATE_CMD
  
  case $PKG_MANAGER in
    apt-get)
      $INSTALL_CMD build-essential libpcre3-dev libssl-dev zlib1g-dev
      ;;
    yum|dnf)
      $INSTALL_CMD gcc make pcre-devel openssl-devel zlib-devel
      ;;
  esac
  
  echo -e "${GREEN}Dependencies installed successfully${NC}"
}

# Download and install NGINX with RTMP module
install_nginx_rtmp() {
  echo -e "${GREEN}Installing NGINX with RTMP module...${NC}"
  
  # Create temporary directory
  mkdir -p /tmp/nginx-rtmp
  cd /tmp/nginx-rtmp
  
  # Download NGINX and RTMP module
  echo -e "${YELLOW}Downloading NGINX and RTMP module...${NC}"
  wget https://nginx.org/download/nginx-1.24.0.tar.gz
  wget https://github.com/arut/nginx-rtmp-module/archive/master.zip
  
  # Extract files
  tar -xzf nginx-1.24.0.tar.gz
  unzip master.zip
  
  # Configure and compile NGINX with RTMP module
  cd nginx-1.24.0
  
  # Configure options
  CONFIGURE_OPTIONS="--prefix=/usr/local/nginx \
                    --with-http_ssl_module \
                    --with-http_v2_module \
                    --with-http_stub_status_module \
                    --add-module=../nginx-rtmp-module-master"
  
  # Add low resource options if requested
  if [ "$LOW_RESOURCE" = true ]; then
    CONFIGURE_OPTIONS="$CONFIGURE_OPTIONS \
                      --with-cc-opt='-Os' \
                      --with-ld-opt='-Wl,--as-needed' \
                      --without-http_charset_module \
                      --without-http_gzip_module \
                      --without-http_ssi_module \
                      --without-http_userid_module \
                      --without-http_access_module \
                      --without-http_auth_basic_module \
                      --without-http_mirror_module \
                      --without-http_autoindex_module \
                      --without-http_geo_module \
                      --without-http_split_clients_module \
                      --without-http_referer_module \
                      --without-http_fastcgi_module \
                      --without-http_uwsgi_module \
                      --without-http_scgi_module \
                      --without-http_grpc_module \
                      --without-http_memcached_module \
                      --without-http_empty_gif_module \
                      --without-http_browser_module"
  fi
  
  # Configure, compile and install
  ./configure $CONFIGURE_OPTIONS
  make -j$(nproc)
  make install
  
  echo -e "${GREEN}NGINX with RTMP module installed successfully${NC}"
}

# Configure NGINX and RTMP
configure_nginx_rtmp() {
  echo -e "${GREEN}Configuring NGINX and RTMP...${NC}"
  
  # Create HLS directory
  mkdir -p $HLS_PATH
  chmod 755 $HLS_PATH
  
  # Create NGINX configuration file
  cat > /usr/local/nginx/conf/nginx.conf <<EOF
worker_processes auto;
events {
    worker_connections 1024;
}

# RTMP configuration
rtmp {
    server {
        listen $RTMP_PORT;
        chunk_size 4096;
        
        # Define application for live streaming
        application live {
            live on;
            record off;
            
            # HLS
            hls on;
            hls_path $HLS_PATH;
            hls_fragment 3;
            hls_playlist_length 60;
        }
    }
}

# HTTP configuration for accessing HLS streams
http {
    include mime.types;
    default_type application/octet-stream;
    sendfile on;
    keepalive_timeout 65;
    
    server {
        listen $HTTP_PORT;
        server_name localhost;
        
        # Serve HLS fragments
        location /hls {
            root $HLS_PATH/..;
            add_header Cache-Control no-cache;
            add_header 'Access-Control-Allow-Origin' '*' always;
            
            # CORS
            if (\$request_method = 'OPTIONS') {
                add_header 'Access-Control-Allow-Origin' '*';
                add_header 'Access-Control-Allow-Methods' 'GET, POST, OPTIONS';
                add_header 'Access-Control-Allow-Headers' 'DNT,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range';
                add_header 'Access-Control-Max-Age' 1728000;
                add_header 'Content-Type' 'text/plain; charset=utf-8';
                add_header 'Content-Length' 0;
                return 204;
            }
            
            types {
                application/vnd.apple.mpegurl m3u8;
                video/mp2t ts;
            }
        }
        
        # Simple status page
        location /status {
            return 200 "RTMP Server Status: OK\nHTTP Port: $HTTP_PORT\nRTMP Port: $RTMP_PORT\n";
        }
    }
}
EOF
  
  echo -e "${GREEN}NGINX and RTMP configured successfully${NC}"
}

# Create systemd service for NGINX
create_nginx_service() {
  echo -e "${GREEN}Creating NGINX systemd service...${NC}"
  
  cat > /etc/systemd/system/nginx-rtmp.service <<EOF
[Unit]
Description=NGINX with RTMP module
After=network.target

[Service]
Type=forking
PIDFile=/usr/local/nginx/logs/nginx.pid
ExecStartPre=/usr/local/nginx/sbin/nginx -t
ExecStart=/usr/local/nginx/sbin/nginx
ExecReload=/usr/local/nginx/sbin/nginx -s reload
ExecStop=/usr/local/nginx/sbin/nginx -s stop
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF
  
  systemctl daemon-reload
  systemctl enable nginx-rtmp
  systemctl start nginx-rtmp
  
  echo -e "${GREEN}NGINX service created and started${NC}"
}

# Check if ports are available
check_ports() {
  echo -e "${YELLOW}Checking if ports are available...${NC}"
  
  # Check if HTTP port is in use
  if command_exists netstat; then
    if netstat -tuln | grep ":$HTTP_PORT " >/dev/null; then
      echo -e "${RED}Warning:${NC} HTTP port $HTTP_PORT is already in use"
      echo "Please choose a different HTTP port with --http-port"
      exit 1
    fi
    
    # Check if RTMP port is in use
    if netstat -tuln | grep ":$RTMP_PORT " >/dev/null; then
      echo -e "${RED}Warning:${NC} RTMP port $RTMP_PORT is already in use"
      echo "Please choose a different RTMP port with --rtmp-port"
      exit 1
    fi
  elif command_exists ss; then
    if ss -tuln | grep ":$HTTP_PORT " >/dev/null; then
      echo -e "${RED}Warning:${NC} HTTP port $HTTP_PORT is already in use"
      echo "Please choose a different HTTP port with --http-port"
      exit 1
    fi
    
    # Check if RTMP port is in use
    if ss -tuln | grep ":$RTMP_PORT " >/dev/null; then
      echo -e "${RED}Warning:${NC} RTMP port $RTMP_PORT is already in use"
      echo "Please choose a different RTMP port with --rtmp-port"
      exit 1
    fi
  fi
  
  echo -e "${GREEN}Ports available${NC}"
}

# Main installation process
main() {
  echo -e "${GREEN}=== RTMP Server Installation Script for Stream Manager ===${NC}"
  echo -e "${GREEN}HTTP Port:${NC} $HTTP_PORT"
  echo -e "${GREEN}RTMP Port:${NC} $RTMP_PORT"
  echo -e "${GREEN}HLS Path:${NC} $HLS_PATH"
  echo -e "${GREEN}Low Resource Mode:${NC} $LOW_RESOURCE"
  echo ""
  
  # Detect OS
  detect_os
  
  # Check if ports are available
  check_ports
  
  # Install dependencies
  install_dependencies
  
  # Install NGINX with RTMP module
  install_nginx_rtmp
  
  # Configure NGINX and RTMP
  configure_nginx_rtmp
  
  # Create systemd service
  create_nginx_service
  
  echo ""
  echo -e "${GREEN}=== Installation Completed Successfully ===${NC}"
  echo -e "${GREEN}RTMP Server is now running${NC}"
  echo -e "${GREEN}RTMP URL:${NC} rtmp://your-server-ip:$RTMP_PORT/live"
  echo -e "${GREEN}Stream key:${NC} stream1"
  echo -e "${GREEN}HLS URL:${NC} http://your-server-ip:$HTTP_PORT/hls/stream1.m3u8"
  echo -e "${GREEN}Status Page:${NC} http://your-server-ip:$HTTP_PORT/status"
  echo ""
  echo -e "${YELLOW}Important:${NC} Make sure to open ports $HTTP_PORT and $RTMP_PORT in your firewall"
  
  # Check if firewall is active and provide instructions
  if command_exists ufw && ufw status | grep -q "active"; then
    echo ""
    echo -e "${YELLOW}Detected UFW firewall. Run these commands to open ports:${NC}"
    echo "sudo ufw allow $HTTP_PORT/tcp"
    echo "sudo ufw allow $RTMP_PORT/tcp"
  elif command_exists firewall-cmd && firewall-cmd --state | grep -q "running"; then
    echo ""
    echo -e "${YELLOW}Detected firewalld. Run these commands to open ports:${NC}"
    echo "sudo firewall-cmd --permanent --add-port=$HTTP_PORT/tcp"
    echo "sudo firewall-cmd --permanent --add-port=$RTMP_PORT/tcp"
    echo "sudo firewall-cmd --reload"
  fi
}

# Run the installation
main