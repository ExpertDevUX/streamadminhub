import { spawn, exec } from "child_process";
import { promisify } from "util";
import { storage } from "./storage";
import { InsertActivity } from "@shared/schema";
import { Express } from "express";
import { log } from "./vite";

const execAsync = promisify(exec);

// Historical metrics storage (in-memory cache)
// In a production system, this would be stored in a database
const metricsCache = new Map<number, any[]>();

// Maximum number of data points to store per server
const MAX_HISTORICAL_DATAPOINTS = 1000;

interface RTMPInstallOptions {
  serverId: number;
  host: string;
  port: number;
  config: any;
}

interface RTMPServerStatus {
  cpu: number;
  memory: number;
  disk: number;
  network: number;
  uptime: number;
}

export function setupRTMPRoutes(app: Express) {
  // Install RTMP server
  app.post('/api/admin/rtmp/install', async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).send("Admin permissions required");
    }

    const { serverId } = req.body;
    try {
      const server = await storage.getServer(serverId);
      if (!server) {
        return res.status(404).send("Server not found");
      }

      const result = await installRTMPServer({
        serverId,
        host: server.host,
        port: server.port,
        config: server.config
      });

      // Log activity
      await storage.createActivity({
        type: "server_install",
        message: `RTMP server installation ${result.success ? "completed" : "failed"} for server ${server.name}`,
        userId: req.user.id,
        relatedId: serverId,
        relatedType: "server"
      });

      res.json(result);
    } catch (error: any) {
      log(`RTMP installation error: ${error.message}`, "rtmp");
      res.status(500).json({ 
        success: false, 
        error: error.message 
      });
    }
  });

  // Start RTMP server
  app.post('/api/admin/rtmp/start', async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).send("Admin permissions required");
    }

    const { serverId } = req.body;
    try {
      const server = await storage.getServer(serverId);
      if (!server) {
        return res.status(404).send("Server not found");
      }

      const result = await startRTMPServer(serverId);
      
      // Update server status
      await storage.updateServer(serverId, { 
        status: result.success ? "online" : "error" 
      });

      // Log activity
      await storage.createActivity({
        type: "server_start",
        message: `RTMP server ${result.success ? "started" : "failed to start"} for server ${server.name}`,
        userId: req.user.id,
        relatedId: serverId,
        relatedType: "server"
      });

      res.json(result);
    } catch (error: any) {
      log(`RTMP start error: ${error.message}`, "rtmp");
      res.status(500).json({ 
        success: false, 
        error: error.message 
      });
    }
  });

  // Stop RTMP server
  app.post('/api/admin/rtmp/stop', async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).send("Admin permissions required");
    }

    const { serverId } = req.body;
    try {
      const server = await storage.getServer(serverId);
      if (!server) {
        return res.status(404).send("Server not found");
      }

      const result = await stopRTMPServer(serverId);

      // Update server status
      await storage.updateServer(serverId, { status: "offline" });

      // Log activity
      await storage.createActivity({
        type: "server_stop",
        message: `RTMP server stopped for server ${server.name}`,
        userId: req.user.id,
        relatedId: serverId,
        relatedType: "server"
      });

      res.json(result);
    } catch (error: any) {
      log(`RTMP stop error: ${error.message}`, "rtmp");
      res.status(500).json({ 
        success: false, 
        error: error.message 
      });
    }
  });

  // Get RTMP server status
  app.get('/api/rtmp/status/:serverId', async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Authentication required");
    }

    const { serverId } = req.params;
    try {
      const server = await storage.getServer(parseInt(serverId));
      if (!server) {
        return res.status(404).send("Server not found");
      }

      const statusData = await getRTMPServerStatus(parseInt(serverId));
      
      // Update server with latest status data
      await storage.updateServer(parseInt(serverId), {
        cpuUsage: statusData.cpu,
        memoryUsage: statusData.memory,
        diskUsage: statusData.disk,
        networkUsage: statusData.network,
        uptime: statusData.uptime
      });

      // Store metrics data for historical tracking
      storeMetricsData(parseInt(serverId), {
        timestamp: Date.now(),
        cpu: statusData.cpu,
        memory: statusData.memory,
        disk: statusData.disk,
        network: statusData.network
      });

      res.json({
        ...server,
        cpuUsage: statusData.cpu,
        memoryUsage: statusData.memory,
        diskUsage: statusData.disk,
        networkUsage: statusData.network,
        uptime: statusData.uptime
      });
    } catch (error: any) {
      log(`RTMP status error: ${error.message}`, "rtmp");
      res.status(500).json({ 
        success: false, 
        error: error.message 
      });
    }
  });
  
  // Get historical metrics for a server
  app.get('/api/rtmp/metrics/:serverId', async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Authentication required");
    }

    const { serverId } = req.params;
    const period = req.query.period as string || 'hour';
    
    try {
      const serverMetrics = getHistoricalMetrics(parseInt(serverId), period);
      res.json(serverMetrics);
    } catch (error: any) {
      log(`Metrics retrieval error: ${error.message}`, "rtmp");
      res.status(500).json({ 
        success: false, 
        error: error.message 
      });
    }
  });

  // Generate stream key
  app.post('/api/streams/generate-key', async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Authentication required");
    }

    const streamKey = generateStreamKey();
    res.json({ streamKey });
  });
}

// Simulated RTMP server installation script
async function installRTMPServer(options: RTMPInstallOptions): Promise<{ success: boolean, message: string }> {
  log(`Installing RTMP server on ${options.host}:${options.port}`, "rtmp");
  
  try {
    // Simulate installation process
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Update server as installed
    await storage.updateServer(options.serverId, { 
      isInstalled: true,
      status: "offline"
    });
    
    return {
      success: true,
      message: "RTMP server installed successfully"
    };
  } catch (error: any) {
    log(`Installation error: ${error.message}`, "rtmp");
    return {
      success: false,
      message: error.message
    };
  }
}

// Simulated RTMP server start function
async function startRTMPServer(serverId: number): Promise<{ success: boolean, message: string }> {
  log(`Starting RTMP server ID: ${serverId}`, "rtmp");
  
  try {
    const server = await storage.getServer(serverId);
    if (!server) {
      throw new Error("Server not found");
    }
    
    if (!server.isInstalled) {
      throw new Error("Server not installed yet");
    }
    
    // Simulate server start
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    return {
      success: true,
      message: "RTMP server started successfully"
    };
  } catch (error: any) {
    return {
      success: false,
      message: error.message
    };
  }
}

// Simulated RTMP server stop function
async function stopRTMPServer(serverId: number): Promise<{ success: boolean, message: string }> {
  log(`Stopping RTMP server ID: ${serverId}`, "rtmp");
  
  try {
    const server = await storage.getServer(serverId);
    if (!server) {
      throw new Error("Server not found");
    }
    
    // Simulate server stop
    await new Promise(resolve => setTimeout(resolve, 500));
    
    return {
      success: true,
      message: "RTMP server stopped successfully"
    };
  } catch (error: any) {
    return {
      success: false,
      message: error.message
    };
  }
}

// Store metrics data for a server
function storeMetricsData(serverId: number, metricsData: any) {
  if (!metricsCache.has(serverId)) {
    metricsCache.set(serverId, []);
  }
  
  const serverMetrics = metricsCache.get(serverId);
  if (serverMetrics) {
    serverMetrics.push(metricsData);
    
    // Trim the array if it exceeds the maximum size
    if (serverMetrics.length > MAX_HISTORICAL_DATAPOINTS) {
      metricsCache.set(serverId, serverMetrics.slice(-MAX_HISTORICAL_DATAPOINTS));
    }
  }
}

// Get historical metrics for a server
function getHistoricalMetrics(serverId: number, period: string = 'hour'): any[] {
  if (!metricsCache.has(serverId)) {
    return [];
  }
  
  const serverMetrics = metricsCache.get(serverId) || [];
  const now = Date.now();
  
  // Filter metrics based on the requested period
  let timeThreshold: number;
  switch (period) {
    case 'hour':
      timeThreshold = now - (60 * 60 * 1000); // 1 hour
      break;
    case 'day':
      timeThreshold = now - (24 * 60 * 60 * 1000); // 24 hours
      break;
    case 'week':
      timeThreshold = now - (7 * 24 * 60 * 60 * 1000); // 7 days
      break;
    default:
      timeThreshold = now - (60 * 60 * 1000); // Default to 1 hour
  }
  
  // Get metrics that fall within the time range
  return serverMetrics.filter(metric => metric.timestamp >= timeThreshold);
}

// Simulated function to get RTMP server status
async function getRTMPServerStatus(serverId: number): Promise<RTMPServerStatus> {
  const server = await storage.getServer(serverId);
  if (!server) {
    throw new Error("Server not found");
  }
  
  if (server.status !== "online") {
    return {
      cpu: 0,
      memory: 0,
      disk: 0,
      network: 0,
      uptime: 0
    };
  }
  
  // For simulating server stats in development
  return {
    cpu: Math.floor(Math.random() * 60) + 10, // 10-70%
    memory: Math.floor(Math.random() * 40) + 30, // 30-70%
    disk: Math.floor(Math.random() * 30) + 10, // 10-40%
    network: Math.floor(Math.random() * 50) + 30, // 30-80%
    uptime: (server.uptime || 0) + 60 // Add a minute to existing uptime, default to 0 if null
  };
}

// Generate a random stream key
function generateStreamKey(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let streamKey = '';
  
  for (let i = 0; i < 24; i++) {
    streamKey += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  
  return streamKey;
}
