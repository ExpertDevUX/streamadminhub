import { useParams, useLocation } from "wouter";
import { useEffect, useMemo } from "react";
import { EmbedPlayer } from "@/components/stream/embed-player";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { ThemeProvider } from "@/components/theme-provider";

export default function EmbedPage() {
  const params = useParams<{ streamKey: string }>();
  const streamKey = params.streamKey;
  const [location] = useLocation();
  
  // Parse query parameters
  const queryParams = useMemo(() => {
    const searchParams = new URLSearchParams(location.split('?')[1] || '');
    return {
      autoplay: searchParams.get('autoplay') !== 'false',
      controls: searchParams.get('controls') !== 'false',
      muted: searchParams.get('muted') === 'true',
      theme: searchParams.get('theme') || 'dark',
    };
  }, [location]);
  
  // Set body to black background and remove margins for embedding
  useEffect(() => {
    document.body.classList.add("embed-mode");
    document.body.style.margin = "0";
    document.body.style.padding = "0";
    document.body.style.overflow = "hidden";
    document.body.style.backgroundColor = "black";
    
    return () => {
      document.body.classList.remove("embed-mode");
      document.body.style.margin = "";
      document.body.style.padding = "";
      document.body.style.overflow = "";
      document.body.style.backgroundColor = "";
    };
  }, []);
  
  if (!streamKey) {
    return (
      <div className="flex items-center justify-center h-screen bg-black text-white p-4 text-center">
        <p>Invalid stream key</p>
      </div>
    );
  }
  
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme={queryParams.theme as "dark" | "light" | "system"}>
        <div className="w-full h-screen bg-black overflow-hidden">
          <EmbedPlayer
            streamKey={streamKey}
            autoplay={queryParams.autoplay}
            controls={queryParams.controls}
            muted={queryParams.muted}
            width="100%"
            height="100%"
          />
        </div>
      </ThemeProvider>
    </QueryClientProvider>
  );
}