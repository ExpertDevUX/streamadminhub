#!/bin/bash

# Video Stream Server Manager - AWS Installation Script
# This script automates the setup of the Video Stream Server Manager on AWS EC2 instances

# Colors for output formatting
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Function to print messages
print_message() {
  echo -e "${GREEN}[+] $1${NC}"
}

print_warning() {
  echo -e "${YELLOW}[!] $1${NC}"
}

print_error() {
  echo -e "${RED}[-] $1${NC}"
}

print_message "Starting AWS installation for Video Stream Server Manager"
print_message "This script will set up your EC2 instance for streaming"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  print_error "Please run as root or with sudo"
  exit 1
fi

# Update and install dependencies
print_message "Updating system and installing dependencies"
apt update -y
apt upgrade -y
apt install -y curl wget build-essential ffmpeg nginx certbot python3-certbot-nginx git

# Install Node.js
print_message "Installing Node.js"
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

# Verify installations
print_message "Verifying installations"
node -v
npm -v

# Create application directory
print_message "Setting up application directory"
mkdir -p /opt/stream-manager
cd /opt/stream-manager

print_message "Cloning application repository"
# Clone from GitHub repository
# Replace with your actual GitHub repository when ready
git clone https://github.com/yourusername/video-stream-server.git .

# Install npm dependencies
print_message "Installing application dependencies"
npm install

# Setup environment file
print_message "Configuring environment variables"
cat > .env << EOF
# Database Configuration
DATABASE_URL=postgresql://username:password@database-host:5432/database-name

# Server Configuration
PORT=5000
NODE_ENV=production
SESSION_SECRET=$(openssl rand -hex 32)

# Set this to your domain if you have one
DOMAIN=
EOF

print_message "Setting up NGINX as a reverse proxy"
cat > /etc/nginx/sites-available/stream-manager << EOF
server {
    listen 80;
    # Replace with your domain or server IP
    server_name _;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
    }

    # For RTMP Stats
    location /rtmp-stats {
        rtmp_stat all;
        rtmp_stat_stylesheet stat.xsl;
        add_header Access-Control-Allow-Origin *;
    }
}
EOF

# Enable the site
ln -sf /etc/nginx/sites-available/stream-manager /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
systemctl restart nginx

# Install PM2 for process management
print_message "Setting up PM2 for process management"
npm install -g pm2
pm2 start "npm run start" --name stream-manager
pm2 startup
pm2 save

# RTMP Server setup
print_message "Setting up RTMP Server"
chmod +x ./install.sh
./install.sh

# Detect public IP address (if available)
PUBLIC_IP=$(curl -s https://api.ipify.org || curl -s https://ipinfo.io/ip || curl -s https://icanhazip.com)

# Use EC2 metadata as fallback if public IP detection fails
if [[ -z "$PUBLIC_IP" ]]; then
    print_warning "Could not detect public IP address using public services. Trying EC2 metadata..."
    PUBLIC_IP=$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4)
    
    if [[ -z "$PUBLIC_IP" ]]; then
        print_warning "Could not detect public IP address from EC2 metadata."
        SERVER_IP=$(hostname -I | awk '{print $1}')
        
        # Check if the IP is a private address
        if [[ "$SERVER_IP" =~ ^(10\.|172\.(1[6-9]|2[0-9]|3[0-1])\.|192\.168\.) ]]; then
            print_warning "Server appears to have a private IP address ($SERVER_IP)."
            print_warning "For public access, you'll need to configure an Elastic IP or check your VPC settings."
        fi
    else
        SERVER_IP="$PUBLIC_IP"
    fi
else
    SERVER_IP="$PUBLIC_IP"
fi

# Generate random admin password if not already set
ADMIN_USERNAME="admin"
if [ -z "$ADMIN_PASSWORD" ]; then
    ADMIN_PASSWORD=$(< /dev/urandom tr -dc A-Za-z0-9 | head -c12)
fi

# Create config file with initial admin credentials
CONFIG_DIR="/etc/stream-manager"
mkdir -p $CONFIG_DIR

cat > $CONFIG_DIR/credentials.conf << EOF
ADMIN_USERNAME=$ADMIN_USERNAME
ADMIN_PASSWORD=$ADMIN_PASSWORD
DASHBOARD_PORT=5000
RTMP_PORT=1935
HTTP_PORT=80
EOF

chmod 600 $CONFIG_DIR/credentials.conf

print_message "Installation completed!"
print_message "Server IP detected: ${SERVER_IP}"
print_message "You can access your stream manager at: http://${SERVER_IP}:5000"

print_message "Default Admin Login:"
print_message "Username: $ADMIN_USERNAME"
print_message "Password: $ADMIN_PASSWORD"
print_message "!! SAVE THIS INFORMATION SECURELY !!"

print_message "RTMP Server: rtmp://${SERVER_IP}:1935/live"
print_message "HLS URL: http://${SERVER_IP}/hls/stream.m3u8"

print_warning "Remember to edit the .env file to configure your database connection"
print_warning "To set up SSL/TLS encryption, run: sudo certbot --nginx -d your-domain.com"

print_message "Required ports for operation:"
print_message "- 1935/tcp: RTMP streaming"
print_message "- 80/tcp: HTTP (web interface & HLS playback)"
print_message "- 443/tcp: HTTPS (secure web interface)"
print_message "- 5000/tcp: API server"

print_message "For more information, check the documentation at: https://github.com/yourusername/video-stream-server"